import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Mock dependencies ────────────────────────────────────────────────────────
vi.mock("./db", () => ({
  getAllItineraries: vi.fn().mockResolvedValue([
    {
      id: 1, title: "Test Tour", destination: "Ujjain", guestNames: "Mr. Test Guest",
      numGuests: 2, startDate: "Mar 28, 2026", endDate: "Mar 30, 2026",
      numNights: 2, numDays: 3, mealPlan: "MAP", transfers: "Private",
      coverImageUrl: null, inclusions: ["Hotel Stay"], exclusions: ["Air Ticket"],
      termsAndConditions: "Standard terms apply", status: "draft",
      createdAt: new Date(), updatedAt: new Date(),
    },
  ]),
  getItineraryById: vi.fn().mockResolvedValue({
    id: 1, title: "Test Tour", destination: "Ujjain", guestNames: "Mr. Test Guest",
    numGuests: 2, startDate: "Mar 28, 2026", endDate: "Mar 30, 2026",
    numNights: 2, numDays: 3, mealPlan: "MAP", transfers: "Private",
    coverImageUrl: null, inclusions: ["Hotel Stay"], exclusions: ["Air Ticket"],
    termsAndConditions: "Standard terms apply", status: "draft",
    createdAt: new Date(), updatedAt: new Date(),
  }),
  getHotelsByItinerary: vi.fn().mockResolvedValue([
    { id: 1, itineraryId: 1, sortOrder: 0, name: "Best Western", starRating: 3, numNights: 2,
      checkInTime: "02:00 PM", checkInDate: "Sat, 28 Mar", checkOutTime: "12:00 PM",
      checkOutDate: "Mon, 30 Mar", imageUrl: null, createdAt: new Date() },
  ]),
  getDaysByItinerary: vi.fn().mockResolvedValue([
    { id: 1, itineraryId: 1, dayNumber: 1, date: "Mar 28, 2026", title: "Arrival", description: "Arrive at Ujjain", imageUrl: null, createdAt: new Date() },
  ]),
  getMealPlansByItinerary: vi.fn().mockResolvedValue([
    { id: 1, itineraryId: 1, dayNumber: 1, date: "28 March 2026", breakfast: 0, lunch: 0, dinner: 1 },
  ]),
  getTransportationByDay: vi.fn().mockResolvedValue([]),
  getTransportationByItinerary: vi.fn().mockResolvedValue([]),
  createItinerary: vi.fn().mockResolvedValue({}),
  updateItinerary: vi.fn().mockResolvedValue({}),
  deleteItinerary: vi.fn().mockResolvedValue({}),
  upsertHotels: vi.fn().mockResolvedValue({}),
  upsertDays: vi.fn().mockResolvedValue({}),
  upsertMealPlans: vi.fn().mockResolvedValue({}),
  upsertTransportationSegments: vi.fn().mockResolvedValue({}),
  getAppSetting: vi.fn().mockResolvedValue(null),
  setAppSetting: vi.fn().mockResolvedValue(undefined),
}));

vi.mock("./storage", () => ({
  storagePut: vi.fn().mockResolvedValue({ url: "https://cdn.example.com/test.pdf", key: "test.pdf" }),
}));

vi.mock("./pdfGenerator", () => ({
  generateItineraryPDF: vi.fn().mockResolvedValue(Buffer.from("fake-pdf")),
}));

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1, openId: "test-user", email: "test@pikme.org", name: "Test Admin",
    loginMethod: "manus", role: "admin",
    createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date(),
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

// ─── Date helper logic (mirrors ItineraryEdit.tsx) ────────────────────────────
const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const MONTHS_FULL = ["January","February","March","April","May","June","July","August","September","October","November","December"];

function parseFlexDate(raw: string): Date | null {
  if (!raw?.trim()) return null;
  const native = new Date(raw);
  if (!isNaN(native.getTime())) return native;
  const cleaned = raw.replace(/,/g, "").trim();
  const parts = cleaned.split(/\s+/);
  if (parts.length === 3) {
    let day: number, month: number, year: number;
    const m1 = [...MONTHS, ...MONTHS_FULL].findIndex(m => m.toLowerCase() === parts[0].toLowerCase());
    if (m1 >= 0) {
      month = m1 % 12; day = parseInt(parts[1]); year = parseInt(parts[2]);
    } else {
      const m2 = [...MONTHS, ...MONTHS_FULL].findIndex(m => m.toLowerCase() === parts[1].toLowerCase());
      if (m2 >= 0) { day = parseInt(parts[0]); month = m2 % 12; year = parseInt(parts[2]); }
      else return null;
    }
    if (!isNaN(day) && !isNaN(year)) return new Date(year, month, day);
  }
  return null;
}

function formatDayDate(d: Date): string {
  return `${MONTHS[d.getMonth()]} ${String(d.getDate()).padStart(2, "0")}, ${d.getFullYear()}`;
}

function formatMealDate(d: Date): string {
  return `${String(d.getDate()).padStart(2, "0")} ${MONTHS_FULL[d.getMonth()]} ${d.getFullYear()}`;
}

function buildDateSequence(startDateStr: string, count: number): string[] {
  const base = parseFlexDate(startDateStr);
  if (!base) return Array(count).fill("");
  return Array.from({ length: count }, (_, i) => {
    const d = new Date(base); d.setDate(base.getDate() + i); return formatDayDate(d);
  });
}

function buildMealDateSequence(startDateStr: string, count: number): string[] {
  const base = parseFlexDate(startDateStr);
  if (!base) return Array(count).fill("");
  return Array.from({ length: count }, (_, i) => {
    const d = new Date(base); d.setDate(base.getDate() + i); return formatMealDate(d);
  });
}

// ─── Date auto-population tests ───────────────────────────────────────────────
describe("parseFlexDate", () => {
  it("parses 'April 02 2026'", () => {
    const d = parseFlexDate("April 02 2026");
    expect(d).not.toBeNull();
    expect(d!.getFullYear()).toBe(2026);
    expect(d!.getMonth()).toBe(3);
    expect(d!.getDate()).toBe(2);
  });

  it("parses 'Apr 02 2026' (short month)", () => {
    const d = parseFlexDate("Apr 02 2026");
    expect(d).not.toBeNull();
    expect(d!.getMonth()).toBe(3);
    expect(d!.getDate()).toBe(2);
  });

  it("parses '02 April 2026' (day-first format)", () => {
    const d = parseFlexDate("02 April 2026");
    expect(d).not.toBeNull();
    expect(d!.getMonth()).toBe(3);
    expect(d!.getDate()).toBe(2);
  });

  it("returns null for empty string", () => {
    expect(parseFlexDate("")).toBeNull();
    expect(parseFlexDate("   ")).toBeNull();
  });

  it("returns null for unparseable string", () => {
    expect(parseFlexDate("not a date")).toBeNull();
  });
});

describe("buildDateSequence (itinerary day dates)", () => {
  it("generates correct dates for 3 days from April 02 2026", () => {
    const seq = buildDateSequence("April 02 2026", 3);
    expect(seq).toHaveLength(3);
    expect(seq[0]).toBe("Apr 02, 2026");
    expect(seq[1]).toBe("Apr 03, 2026");
    expect(seq[2]).toBe("Apr 04, 2026");
  });

  it("handles month boundary (Mar 30 + 3 days crosses into April)", () => {
    const seq = buildDateSequence("March 30 2026", 3);
    expect(seq[0]).toBe("Mar 30, 2026");
    expect(seq[1]).toBe("Mar 31, 2026");
    expect(seq[2]).toBe("Apr 01, 2026");
  });

  it("returns empty strings when start date is invalid", () => {
    expect(buildDateSequence("", 3)).toEqual(["", "", ""]);
  });
});

describe("buildMealDateSequence (meal plan dates)", () => {
  it("generates correct meal dates for 3 days from April 02 2026", () => {
    const seq = buildMealDateSequence("April 02 2026", 3);
    expect(seq).toHaveLength(3);
    expect(seq[0]).toBe("02 April 2026");
    expect(seq[1]).toBe("03 April 2026");
    expect(seq[2]).toBe("04 April 2026");
  });

  it("pads single-digit days with leading zero", () => {
    const seq = buildMealDateSequence("April 02 2026", 1);
    expect(seq[0]).toMatch(/^0\d /);
  });

  it("returns empty strings when start date is invalid", () => {
    expect(buildMealDateSequence("", 2)).toEqual(["", ""]);
  });
});

// ─── Router tests ─────────────────────────────────────────────────────────────
describe("itinerary router", () => {
  const ctx = createAuthContext();
  const caller = appRouter.createCaller(ctx);

  it("list returns itineraries", async () => {
    const result = await caller.itinerary.list();
    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBeGreaterThan(0);
    expect(result[0].title).toBe("Test Tour");
  });

  it("get returns full itinerary with hotels, days, mealPlans", async () => {
    const result = await caller.itinerary.get({ id: 1 });
    expect(result.title).toBe("Test Tour");
    expect(result.hotels).toHaveLength(1);
    expect(result.days).toHaveLength(1);
    expect(result.mealPlans).toHaveLength(1);
    expect(result.hotels[0].name).toBe("Best Western");
    expect(result.days[0].title).toBe("Arrival");
  });

  it("get throws for non-existent itinerary", async () => {
    const { getItineraryById } = await import("./db");
    vi.mocked(getItineraryById).mockResolvedValueOnce(undefined);
    await expect(caller.itinerary.get({ id: 999 })).rejects.toThrow("Itinerary not found");
  });

  it("delete calls deleteItinerary and returns success", async () => {
    const result = await caller.itinerary.delete({ id: 1 });
    expect(result.success).toBe(true);
  });

  it("generatePDF returns a CDN URL", async () => {
    const result = await caller.itinerary.generatePDF({ id: 1 });
    expect(result.url).toContain("https://");
  });

  it("update returns success", async () => {
    const payload = {
      title: "Updated Tour", destination: "Ujjain", guestNames: "Mr. Guest",
      numGuests: 2, startDate: "Apr 02, 2026", endDate: "Apr 04, 2026",
      numNights: 2, numDays: 3, mealPlan: "MAP", transfers: "Private",
      coverImageUrl: null, inclusions: ["Hotel"], exclusions: ["Air"],
      termsAndConditions: "Terms",
      hotels: [{ name: "Hotel A", starRating: 3, numNights: 2, checkInTime: "2PM", checkInDate: "Apr 02", checkOutTime: "12PM", checkOutDate: "Apr 04", imageUrl: null }],
      days: [{ dayNumber: 1, date: "Apr 02, 2026", title: "Arrival", description: "Arrive", imageUrl: null }],
      mealPlans: [{ dayNumber: 1, date: "02 April 2026", breakfast: 0, lunch: 0, dinner: 1 }],
    };
    const result = await caller.itinerary.update({ id: 1, data: payload });
    expect(result.success).toBe(true);
  });

  it("update accepts new date/time picker fields for arrival and return legs", async () => {
    const payload = {
      title: "Flight Tour", destination: "Ujjain", guestNames: "Mr. Guest",
      numGuests: 2, startDate: "Apr 02, 2026", endDate: "Apr 04, 2026",
      numNights: 2, numDays: 3, mealPlan: "MAP", transfers: "Private",
      tripType: "flight-rt",
      arrivalFrom: "Mumbai", arrivalTo: "Indore",
      arrivalFlightNo: "AI 2345", arrivalAirline: "Air India", arrivalStops: "direct",
      arrivalDepartureDate: "Apr 02, 2026", arrivalDepartureTime: "06:30 AM",
      arrivalArrivalDate: "Apr 02, 2026", arrivalArrivalTime: "09:15 AM",
      returnFlightNo: "AI 2346", returnAirline: "Air India", returnStops: "direct",
      returnDepartureDate: "Apr 04, 2026", returnDepartureTime: "05:00 PM",
      returnArrivalDate: "Apr 04, 2026", returnArrivalTime: "08:30 PM",
      coverImageUrl: null, inclusions: ["Hotel"], exclusions: ["Air"],
      termsAndConditions: "Terms",
      hotels: [{ name: "Hotel A", starRating: 3, numNights: 2, checkInTime: "2PM", checkInDate: "Apr 02", checkOutTime: "12PM", checkOutDate: "Apr 04", imageUrl: null }],
      days: [{ dayNumber: 1, date: "Apr 02, 2026", title: "Arrival", description: "Arrive", imageUrl: null }],
      mealPlans: [{ dayNumber: 1, date: "02 April 2026", breakfast: 0, lunch: 0, dinner: 1 }],
    };
    const result = await caller.itinerary.update({ id: 1, data: payload });
    expect(result.success).toBe(true);
  });
});

describe("auth router", () => {
  it("me returns authenticated user", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const user = await caller.auth.me();
    expect(user?.name).toBe("Test Admin");
  });

  it("logout clears cookie and returns success", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result.success).toBe(true);
  });
});
