import { readFileSync } from "fs";
import { createRequire } from "module";
import https from "https";
import http from "http";
import type { HotelVoucher } from "../drizzle/schema";

const require = createRequire(import.meta.url);

// ─── Helpers ──────────────────────────────────────────────────────────────────
// Fetch a URL and return a Buffer (follows HTTP 301/302/307/308 redirects)
function fetchBuffer(url: string, redirectsLeft = 5): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const mod = url.startsWith("https") ? https : http;
    mod.get(url, (res) => {
      const { statusCode, headers } = res;
      // Follow redirects
      if ((statusCode === 301 || statusCode === 302 || statusCode === 307 || statusCode === 308) && headers.location && redirectsLeft > 0) {
        res.resume(); // Drain to free socket
        fetchBuffer(headers.location, redirectsLeft - 1).then(resolve).catch(reject);
        return;
      }
      if (statusCode && statusCode >= 400) {
        res.resume();
        reject(new Error(`HTTP ${statusCode} fetching image: ${url}`));
        return;
      }
      const chunks: Buffer[] = [];
      res.on("data", (c: Buffer) => chunks.push(c));
      res.on("end", () => resolve(Buffer.concat(chunks)));
      res.on("error", reject);
    }).on("error", reject);
  });
}

async function fetchBase64(url: string): Promise<string | null> {
  if (!url) return null;
  try {
    const buf = await fetchBuffer(url);
    // Detect mime type from buffer magic bytes or fall back to jpeg
    let mime = "image/jpeg";
    if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) mime = "image/png";
    else if (buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46) mime = "image/gif";
    else if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) mime = "image/jpeg";
    else if (buf[0] === 0x52 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x46) mime = "image/webp";
    return `data:${mime};base64,${buf.toString("base64")}`;
  } catch {
    return null;
  }
}

function starsCanvas(n: number) {
  const filled = Math.min(Math.max(n, 0), 5);
  const circles: any[] = [];
  const r = 5;
  const gap = 14;
  for (let i = 0; i < 5; i++) {
    const cx = i * gap + r;
    circles.push({
      type: "ellipse",
      x: cx, y: r,
      r1: r, r2: r,
      color: i < filled ? GOLD : undefined,
      lineColor: GOLD,
      lineWidth: 1,
    });
  }
  return {
    columns: [
      { canvas: circles, width: 5 * gap, height: r * 2 + 2 },
      { text: ` ${filled}-Star Hotel`, fontSize: 8.5, color: MID_GRAY, margin: [4, 1, 0, 0] },
    ],
    margin: [0, 0, 0, 2],
  };
}

// ─── pdfmake setup ────────────────────────────────────────────────────────────
let _pdfmakeReady = false;
let _pdfmake: any = null;
let _fontName = "Roboto";

function getPdfmake() {
  if (_pdfmakeReady) return _pdfmake;
  _pdfmake = require("pdfmake/js/index.js");
  try {
    const notoDir = require.resolve("@fontsource/noto-sans").replace(/index\.css$/, "files/");
    _pdfmake.virtualfs.writeFileSync("NotoSans-Regular.ttf", readFileSync(notoDir + "noto-sans-400-normal.ttf"));
    _pdfmake.virtualfs.writeFileSync("NotoSans-Bold.ttf", readFileSync(notoDir + "noto-sans-700-normal.ttf"));
    _pdfmake.addFonts({
      NotoSans: { normal: "NotoSans-Regular.ttf", bold: "NotoSans-Bold.ttf", italics: "NotoSans-Regular.ttf", bolditalics: "NotoSans-Bold.ttf" },
    });
    _pdfmake.setFonts({ NotoSans: { normal: "NotoSans-Regular.ttf", bold: "NotoSans-Bold.ttf", italics: "NotoSans-Regular.ttf", bolditalics: "NotoSans-Bold.ttf" } });
    _fontName = "NotoSans";
  } catch {
    const robotoDir = require.resolve("pdfmake").replace(/js\/index\.js$/, "fonts/Roboto/");
    _pdfmake.virtualfs.writeFileSync("Roboto-Regular.ttf", readFileSync(robotoDir + "Roboto-Regular.ttf"));
    _pdfmake.virtualfs.writeFileSync("Roboto-Medium.ttf", readFileSync(robotoDir + "Roboto-Medium.ttf"));
    _pdfmake.addFonts({
      Roboto: { normal: "Roboto-Regular.ttf", bold: "Roboto-Medium.ttf", italics: "Roboto-Regular.ttf", bolditalics: "Roboto-Medium.ttf" },
    });
    _fontName = "Roboto";
  }
  _pdfmakeReady = true;
  return _pdfmake;
}

// ─── Design tokens ────────────────────────────────────────────────────────────
const RED      = "#c0392b";
const DARK     = "#1a202c";
const MID_GRAY = "#4a5568";
const LIGHT_GRAY = "#f7fafc";
const BORDER   = "#e2e8f0";
const WHITE    = "#ffffff";
const GOLD     = "#d4a017";

// ─── Helpers ──────────────────────────────────────────────────────────────────
function divider() {
  return { canvas: [{ type: "line", x1: 0, y1: 0, x2: 515, y2: 0, lineWidth: 0.5, lineColor: BORDER }], margin: [0, 6, 0, 6] };
}

function sectionTitle(text: string) {
  return {
    text: text.toUpperCase(),
    fontSize: 7.5,
    bold: true,
    color: RED,
    characterSpacing: 1.2,
    margin: [0, 10, 0, 5],
  };
}

function row(label: string, value: string | number | null | undefined, opts: { bold?: boolean } = {}) {
  if (value === null || value === undefined || value === "") return null;
  return {
    columns: [
      { text: label, width: 120, fontSize: 9, color: MID_GRAY },
      { text: String(value), fontSize: 9, bold: opts.bold ?? false, color: DARK },
    ],
    margin: [0, 2, 0, 2],
  };
}

// ─── Main PDF builder ─────────────────────────────────────────────────────────
async function buildVoucherDocDefinition(v: HotelVoucher, companyLogoUrl: string): Promise<any> {
  const [logoB64, hotelImgB64] = await Promise.all([
    fetchBase64(companyLogoUrl),
    v.hotelImageUrl ? fetchBase64(v.hotelImageUrl) : Promise.resolve(null),
  ]);

  const guestList: Array<{ name: string; category: string }> =
    Array.isArray(v.guestList) ? (v.guestList as any[]) : [];
  const inclusions: string[] = Array.isArray(v.inclusions) ? (v.inclusions as string[]) : [];

  const content: any[] = [];

  // ── HEADER: white background, logo left, title right ─────────────────────
  content.push({
    table: {
      widths: [180, "*"],
      body: [[
        // Left: logo
        logoB64
          ? { image: logoB64, width: 130, margin: [0, 6, 0, 6] }
          : { text: "PIKME", fontSize: 22, bold: true, color: RED, margin: [0, 10, 0, 10] },
        // Right: title block
        {
          stack: [
            { text: "HOTEL CONFIRMATION VOUCHER", fontSize: 13, bold: true, color: DARK, alignment: "right" },
            { text: "www.pikme.org", fontSize: 8, color: RED, alignment: "right", margin: [0, 2, 0, 2] },
            ...(v.bookingRef ? [{ text: `Voucher No: ${v.bookingRef}`, fontSize: 8.5, color: MID_GRAY, alignment: "right" }] : []),
            ...(v.bookingDate ? [{ text: `Date: ${v.bookingDate}`, fontSize: 8.5, color: MID_GRAY, alignment: "right" }] : []),
          ],
          margin: [0, 6, 0, 6],
        },
      ]],
    },
    layout: {
      fillColor: () => WHITE,
      hLineWidth: () => 0,
      vLineWidth: () => 0,
      paddingLeft: () => 0,
      paddingRight: () => 0,
      paddingTop: () => 0,
      paddingBottom: () => 0,
    },
    margin: [0, 0, 0, 0],
  });

  // Red accent bar below header
  content.push({ canvas: [{ type: "rect", x: 0, y: 0, w: 515, h: 3, color: RED }], margin: [0, 0, 0, 0] });

  // Status + hotel name banner
  const statusColor = v.status === "confirmed" ? "#276749" : "#744210";
  const statusBg    = v.status === "confirmed" ? "#c6f6d5" : "#fefcbf";
  content.push({
    columns: [
      { text: v.hotelName?.toUpperCase() || "", fontSize: 12, bold: true, color: DARK },
      {
        text: v.status?.toUpperCase() || "DRAFT",
        fontSize: 7.5,
        bold: true,
        color: statusColor,
        background: statusBg,
        alignment: "right",
        margin: [0, 2, 0, 0],
      },
    ],
    margin: [0, 8, 0, 2],
  });

  // Star rating row
  if (v.starRating > 0) {
    content.push(starsCanvas(v.starRating));
  }

  // Hotel address/phone/email in one compact line
  const hotelMeta = [v.hotelAddress, v.hotelPhone, v.hotelEmail].filter(Boolean).join("  •  ");
  if (hotelMeta) {
    content.push({ text: hotelMeta, fontSize: 8, color: MID_GRAY, margin: [0, 0, 0, 2] });
  }
  if (v.hotelConfirmationNo) {
    content.push({ text: `Confirmation No: ${v.hotelConfirmationNo}`, fontSize: 8.5, bold: true, color: RED, margin: [0, 2, 0, 0] });
  }

  content.push(divider());

  // ── Hotel image (if available) ────────────────────────────────────────────
  if (hotelImgB64) {
    content.push({
      image: hotelImgB64,
      width: 515,
      height: 130,
      fit: [515, 130],
      margin: [0, 0, 0, 8],
    });
  }

  // ── STAY DETAILS: 4-column info card ─────────────────────────────────────
  content.push(sectionTitle("Stay Details"));
  content.push({
    table: {
      widths: ["*", "*", "*", "*"],
      body: [
        [
          { text: "CHECK-IN", fontSize: 7, bold: true, color: WHITE, alignment: "center", fillColor: DARK },
          { text: "CHECK-OUT", fontSize: 7, bold: true, color: WHITE, alignment: "center", fillColor: DARK },
          { text: "NIGHTS", fontSize: 7, bold: true, color: WHITE, alignment: "center", fillColor: DARK },
          { text: "ROOMS", fontSize: 7, bold: true, color: WHITE, alignment: "center", fillColor: DARK },
        ],
        [
          {
            stack: [
              { text: v.checkInDate || "—", fontSize: 10, bold: true, alignment: "center", color: DARK },
              { text: v.checkInTime || "", fontSize: 7.5, color: MID_GRAY, alignment: "center" },
              ...(v.earlyCheckIn ? [{ text: "Early Check-In ✓", fontSize: 7, color: "#276749", alignment: "center" }] : []),
            ],
          },
          {
            stack: [
              { text: v.checkOutDate || "—", fontSize: 10, bold: true, alignment: "center", color: DARK },
              { text: v.checkOutTime || "", fontSize: 7.5, color: MID_GRAY, alignment: "center" },
              ...(v.lateCheckOut ? [{ text: "Late Check-Out ✓", fontSize: 7, color: "#276749", alignment: "center" }] : []),
            ],
          },
          { text: String(v.numNights), fontSize: 18, bold: true, alignment: "center", color: RED },
          { text: String(v.numRooms), fontSize: 18, bold: true, alignment: "center", color: RED },
        ],
      ],
    },
    layout: {
      fillColor: (row: number) => row === 0 ? DARK : LIGHT_GRAY,
      hLineWidth: () => 0.5,
      vLineWidth: () => 0.5,
      hLineColor: () => BORDER,
      vLineColor: () => BORDER,
      paddingTop: () => 6,
      paddingBottom: () => 6,
      paddingLeft: () => 4,
      paddingRight: () => 4,
    },
    margin: [0, 0, 0, 10],
  });

  // ── GUEST INFORMATION & ROOM DETAILS side-by-side ─────────────────────────
  content.push(sectionTitle("Guest & Room Information"));

  const occupancyParts: string[] = [];
  if (v.doubleSharing > 0) occupancyParts.push(`${v.doubleSharing} Double`);
  if (v.tripleSharing > 0) occupancyParts.push(`${v.tripleSharing} Triple`);
  if (v.childWithBed > 0) occupancyParts.push(`${v.childWithBed} Child (Bed)`);
  if (v.childNoBed > 0) occupancyParts.push(`${v.childNoBed} Child (No Bed)`);
  if (v.extraBed > 0) occupancyParts.push(`${v.extraBed} Extra Bed`);

  const guestCol = {
    stack: [
      { text: "GUEST INFORMATION", fontSize: 7, bold: true, color: MID_GRAY, margin: [0, 0, 0, 4] },
      ...[
        row("Lead Guest", v.guestName, { bold: true }),
        row("Total Guests", v.numGuests),
        ...(guestList.length > 0 ? [{
          columns: [
            { text: "Guest List", width: 120, fontSize: 9, color: MID_GRAY },
            {
              stack: guestList.map((g) => ({
                text: `${g.name}${g.category ? ` (${g.category})` : ""}`,
                fontSize: 9, color: DARK,
              })),
            },
          ],
          margin: [0, 2, 0, 2],
        }] : []),
      ].filter(Boolean),
    ],
  };

  const roomCol = {
    stack: [
      { text: "ROOM INFORMATION", fontSize: 7, bold: true, color: MID_GRAY, margin: [0, 0, 0, 4] },
      ...[
        row("Room Type", v.roomType, { bold: true }),
        row("Occupancy", occupancyParts.join(", ") || "—"),
        row("Meal Plan", v.mealPlan),
        row("Food Preference", v.foodPreference),
      ].filter(Boolean),
    ],
  };

  content.push({
    columns: [
      { ...guestCol, width: "50%" },
      { width: 12, text: "" },
      { ...roomCol, width: "*" },
    ],
    margin: [0, 0, 0, 10],
  });

  // ── INCLUSIONS ────────────────────────────────────────────────────────────
  if (inclusions.length > 0) {
    content.push(divider());
    content.push(sectionTitle("Inclusions"));
    // Two-column layout for inclusions
    const half = Math.ceil(inclusions.length / 2);
    const left = inclusions.slice(0, half);
    const right = inclusions.slice(half);
    content.push({
      columns: [
        {
          ul: left.map((inc) => ({ text: inc, fontSize: 8.5, color: DARK })),
          width: "50%",
        },
        {
          ul: right.map((inc) => ({ text: inc, fontSize: 8.5, color: DARK })),
          width: "*",
        },
      ],
      margin: [0, 0, 0, 8],
    });
  }

  // ── SPECIAL REQUESTS ──────────────────────────────────────────────────────
  if (v.specialRequests) {
    content.push(divider());
    content.push(sectionTitle("Special Requests / Notes"));
    content.push({
      text: v.specialRequests,
      fontSize: 8.5,
      color: DARK,
      italics: true,
      margin: [0, 0, 0, 8],
    });
  }

  // ── AGENT ─────────────────────────────────────────────────────────────────
  if (v.agentName || v.agentPhone) {
    content.push(divider());
    content.push(sectionTitle("Travel Consultant"));
    content.push({
      columns: [
        row("Consultant Name", v.agentName, { bold: true }),
        row("Contact", v.agentPhone),
      ].filter(Boolean),
      margin: [0, 0, 0, 8],
    });
  }

  return {
    content,
    defaultStyle: {
      font: _fontName,
      fontSize: 9,
      color: DARK,
      lineHeight: 1.3,
    },
    pageSize: "A4",
    pageMargins: [40, 40, 40, 50],
    footer: (currentPage: number, pageCount: number) => ({
      columns: [
        { text: "This is a computer-generated voucher. Please present at check-in.", fontSize: 7, color: "#a0aec0", margin: [40, 0, 0, 0] },
        { text: `Powered by Pikme.org  |  www.pikme.org  |  Page ${currentPage} of ${pageCount}`, fontSize: 7, color: "#a0aec0", alignment: "right", margin: [0, 0, 40, 0] },
      ],
      margin: [0, 8, 0, 0],
    }),
  };
}

// ─── Exported function ────────────────────────────────────────────────────────
export async function generateVoucherPDF(
  v: HotelVoucher,
  companyLogoUrl = "https://pikme.in/cdn/logo-banner/pikme-logo-600.png"
): Promise<Buffer> {
  const pdfmake = getPdfmake();
  const docDefinition = await buildVoucherDocDefinition(v, companyLogoUrl);
  const doc = pdfmake.createPdf(docDefinition);
  return await doc.getBuffer() as Buffer;
}
