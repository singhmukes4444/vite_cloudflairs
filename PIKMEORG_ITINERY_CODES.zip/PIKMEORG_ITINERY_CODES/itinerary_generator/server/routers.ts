import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import {
  getAllItineraries, getItineraryById, createItinerary, updateItinerary, deleteItinerary, duplicateItinerary,
  getHotelsByItinerary, upsertHotels,
  getDaysByItinerary, upsertDays,
  getMealPlansByItinerary, upsertMealPlans,
  getAppSetting, setAppSetting,
  getAllVouchers, getVoucherById, createVoucher, updateVoucher, deleteVoucher, duplicateVoucher,
  getTransportationByDay, getTransportationByItinerary, upsertTransportationSegments,
} from "./db";
import { storagePut } from "./storage";
import { generateItineraryPDF, generateItineraryDOCX } from "./pdfGenerator";
import { nanoid } from "nanoid";

// ─── Zod Schemas ──────────────────────────────────────────────────────────
const HotelInput = z.object({
  destinationName: z.string().optional().default(""),
  name: z.string(),
  starRating: z.number().int().min(1).max(5),
  numNights: z.number().int().min(1),
  checkInTime: z.string(),
  checkInDate: z.string(),
  checkOutTime: z.string(),
  checkOutDate: z.string(),
  specialNotes: z.string().nullable().optional(),
  imageUrl: z.string().nullable().optional(),
  numRooms: z.number().int().min(0).optional().default(0),
  doubleSharing: z.number().int().min(0).optional().default(0),
  tripleSharing: z.number().int().min(0).optional().default(0),
  childNoBed: z.number().int().min(0).optional().default(0),
  childWithBed: z.number().int().min(0).optional().default(0),
  extraBed: z.number().int().min(0).optional().default(0),
  mealPlan: z.string().optional().default("MAPI"),
  foodPreference: z.string().optional().default(""),
});

const TransportationSegmentInput = z.object({
  id: z.union([z.number(), z.string()]).optional(),
  type: z.enum(["flight", "train", "car", "bus", "taxi", "ship", "other"]),
  departureLocation: z.string(),
  departureDate: z.string(),
  departureTime: z.string(),
  arrivalLocation: z.string(),
  arrivalDate: z.string(),
  arrivalTime: z.string(),
  flightNumber: z.string().optional().default(""),
  airline: z.string().optional().default(""),
  trainNumber: z.string().optional().default(""),
  trainName: z.string().optional().default(""),
  vehicleType: z.string().optional().default(""),
  vehicleNumber: z.string().optional().default(""),
});

const DayInput = z.object({
  dayNumber: z.number().int().min(1),
  date: z.string(),
  title: z.string(),
  description: z.string(),
  imageUrl: z.string().nullable().optional(),
  transportationSegments: z.array(TransportationSegmentInput).optional().default([]),
});

const MealPlanInput = z.object({
  dayNumber: z.number().int().min(1),
  date: z.string(),
  breakfast: z.number().int().min(0),
  breakfastType: z.string().optional().default(""),
  lunch: z.number().int().min(0),
  lunchType: z.string().optional().default(""),
  dinner: z.number().int().min(0),
  dinnerType: z.string().optional().default(""),
});

const ItineraryInput = z.object({
  title: z.string().min(1),
  destination: z.string(),
  guestNames: z.string(),
  guestList: z.array(z.object({ name: z.string(), category: z.string() })).optional(),
  numGuests: z.number().int().min(1),
  startDate: z.string(),
  endDate: z.string(),
  numNights: z.number().int().min(1),
  numDays: z.number().int().min(1),
  mealPlan: z.string().optional().default(""),
  foodPreference: z.string().optional().default(""),
  transfers: z.string(),
  tripType: z.string().optional().default("flight-rt"),
  // Arrival
  arrivalType: z.string().optional().default("flight"),
  arrivalFrom: z.string().optional().default(""),
  arrivalTo: z.string().optional().default(""),
  arrivalFlightNo: z.string().optional().default(""),
  arrivalAirline: z.string().optional().default(""),
  arrivalStops: z.string().optional().default("direct"),
  arrivalDepartureDate: z.string().optional().default(""),
  arrivalDepartureTime: z.string().optional().default(""),
  arrivalArrivalDate: z.string().optional().default(""),
  arrivalArrivalTime: z.string().optional().default(""),
  // Return
  returnFlightNo: z.string().optional().default(""),
  returnAirline: z.string().optional().default(""),
  returnStops: z.string().optional().default("direct"),
  returnFrom: z.string().optional().default(""),
  returnTo: z.string().optional().default(""),
  returnDepartureDate: z.string().optional().default(""),
  returnDepartureTime: z.string().optional().default(""),
  returnArrivalDate: z.string().optional().default(""),
  returnArrivalTime: z.string().optional().default(""),
  coverImageUrl: z.string().nullable().optional(),
  specialNotes: z.string().nullable().optional(),
  inclusions: z.array(z.string()),
  exclusions: z.array(z.string()),
  termsAndConditions: z.string(),
  status: z.enum(["draft", "published"]).optional(),
  hotels: z.array(HotelInput),
  days: z.array(DayInput),
  mealPlans: z.array(MealPlanInput),
});

// ─── Voucher Zod Schema ─────────────────────────────────────────────────────────────────────
const VoucherInput = z.object({
  bookingRef: z.string().optional().default(""),
  bookingDate: z.string().optional().default(""),
  guestName: z.string().optional().default(""),
  guestList: z.array(z.object({ name: z.string(), category: z.string() })).optional().default([]),
  numGuests: z.number().int().min(1).optional().default(1),
  hotelName: z.string().min(1),
  hotelAddress: z.string().nullable().optional(),
  hotelPhone: z.string().optional().default(""),
  hotelEmail: z.string().optional().default(""),
  starRating: z.number().int().min(1).max(5).optional().default(3),
  hotelImageUrl: z.string().nullable().optional(),
  checkInDate: z.string().optional().default(""),
  checkInTime: z.string().optional().default("02:00 PM"),
  checkOutDate: z.string().optional().default(""),
  checkOutTime: z.string().optional().default("12:00 PM"),
  numNights: z.number().int().min(1).optional().default(1),
  roomType: z.string().optional().default(""),
  numRooms: z.number().int().min(0).optional().default(1),
  doubleSharing: z.number().int().min(0).optional().default(0),
  tripleSharing: z.number().int().min(0).optional().default(0),
  childNoBed: z.number().int().min(0).optional().default(0),
  childWithBed: z.number().int().min(0).optional().default(0),
  extraBed: z.number().int().min(0).optional().default(0),
  mealPlan: z.string().optional().default(""),
  foodPreference: z.string().optional().default(""),
  inclusions: z.array(z.string()).optional().default([]),
  specialRequests: z.string().nullable().optional(),
  hotelConfirmationNo: z.string().optional().default(""),
  agentName: z.string().optional().default(""),
  agentPhone: z.string().optional().default(""),
  status: z.enum(["draft", "confirmed"]).optional().default("draft"),
  earlyCheckIn: z.number().int().min(0).max(1).optional().default(0),
  lateCheckOut: z.number().int().min(0).max(1).optional().default(0),
});

// ─── Router ─────────────────────────────────────────────────────────────────────
export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  itinerary: router({
    list: protectedProcedure.query(async () => {
      return getAllItineraries();
    }),

    get: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const itin = await getItineraryById(input.id);
      if (!itin) throw new Error("Itinerary not found");
      const [hotelList, dayList, mealList] = await Promise.all([
        getHotelsByItinerary(input.id),
        getDaysByItinerary(input.id),
        getMealPlansByItinerary(input.id),
      ]);
      // Fetch transportation segments for each day
      const daysWithTransportation = await Promise.all(
        dayList.map(async (day) => ({
          ...day,
          transportationSegments: await getTransportationByDay(day.id),
        }))
      );
      return { ...itin, hotels: hotelList, days: daysWithTransportation, mealPlans: mealList };
    }),

    publicGet: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const itin = await getItineraryById(input.id);
      if (!itin) throw new Error("Itinerary not found");
      const [hotelList, dayList, mealList] = await Promise.all([
        getHotelsByItinerary(input.id),
        getDaysByItinerary(input.id),
        getMealPlansByItinerary(input.id),
      ]);
      // Fetch transportation segments for each day
      const daysWithTransportation = await Promise.all(
        dayList.map(async (day) => ({
          ...day,
          transportationSegments: await getTransportationByDay(day.id),
        }))
      );
      return { ...itin, hotels: hotelList, days: daysWithTransportation, mealPlans: mealList };
    }),

    create: protectedProcedure.input(ItineraryInput).mutation(async ({ input }) => {
      const { hotels, days, mealPlans: meals, ...itinData } = input;
      const result = await createItinerary({
        ...itinData,
        guestNames: itinData.guestNames,
        guestList: itinData.guestList ?? null,
        termsAndConditions: itinData.termsAndConditions,
        inclusions: itinData.inclusions,
        exclusions: itinData.exclusions,
        status: itinData.status ?? "draft",
      });
      // Get the inserted ID
      const all = await getAllItineraries();
      const newItin = all[0]; // most recent
      if (newItin) {
        await upsertHotels(newItin.id, hotels);
        await upsertDays(newItin.id, days.map(d => ({ ...d, description: d.description })));
        await upsertMealPlans(newItin.id, meals);
        const dayList = await getDaysByItinerary(newItin.id);
        for (const day of days) {
          if (day.transportationSegments && day.transportationSegments.length > 0) {
            const dayRecord = dayList.find((d: any) => d.dayNumber === day.dayNumber);
            if (dayRecord) {
              await upsertTransportationSegments(newItin.id, Number(dayRecord.id), day.transportationSegments.map((t: any) => ({
                type: t.type,
                originLocation: t.departureLocation,
                originDate: t.departureDate,
                originTime: t.departureTime,
                destinationLocation: t.arrivalLocation,
                destinationDate: t.arrivalDate,
                destinationTime: t.arrivalTime,
                flightNumber: t.flightNumber || "",
                airline: t.airline || "",
                trainNumber: t.trainNumber || "",
                trainName: t.trainName || "",
                vehicleType: t.vehicleType || "",
                vehicleNumber: t.vehicleNumber || "",
              })));
            }
          }
        }
      }
      return newItin;
    }),

    update: protectedProcedure
      .input(z.object({ id: z.number(), data: ItineraryInput }))
      .mutation(async ({ input }) => {
        const { hotels, days, mealPlans: meals, ...itinData } = input.data;
        await updateItinerary(input.id, {
          ...itinData,
          guestNames: itinData.guestNames,
          guestList: itinData.guestList ?? null,
          termsAndConditions: itinData.termsAndConditions,
          inclusions: itinData.inclusions,
          exclusions: itinData.exclusions,
          status: itinData.status ?? "draft",
        });
        await upsertHotels(input.id, hotels);
        await upsertDays(input.id, days.map(d => ({ ...d, description: d.description })));
        await upsertMealPlans(input.id, meals);
        const dayList = await getDaysByItinerary(input.id);
        for (const day of days) {
          if (day.transportationSegments && day.transportationSegments.length > 0) {
            const dayRecord = dayList.find((d: any) => d.dayNumber === day.dayNumber);
            if (dayRecord) {
              await upsertTransportationSegments(input.id, Number(dayRecord.id), day.transportationSegments.map((t: any) => ({
                type: t.type,
                originLocation: t.departureLocation,
                originDate: t.departureDate,
                originTime: t.departureTime,
                destinationLocation: t.arrivalLocation,
                destinationDate: t.arrivalDate,
                destinationTime: t.arrivalTime,
                flightNumber: t.flightNumber || "",
                airline: t.airline || "",
                trainNumber: t.trainNumber || "",
                trainName: t.trainName || "",
                vehicleType: t.vehicleType || "",
                vehicleNumber: t.vehicleNumber || "",
              })));
            }
          }
        }
        return { success: true };
      }),

    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await deleteItinerary(input.id);
      return { success: true };
    }),

    duplicate: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      const newItinId = await duplicateItinerary(input.id);
      const newItin = await getItineraryById(newItinId);
      return newItin;
    }),

    generateDOCX: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      const itin = await getItineraryById(input.id);
      if (!itin) throw new Error("Itinerary not found");
      const [hotelList, dayList, mealList] = await Promise.all([
        getHotelsByItinerary(input.id),
        getDaysByItinerary(input.id),
        getMealPlansByItinerary(input.id),
      ]);
      const logoUrl = await getAppSetting("logoUrl");
      const companyLogoUrl = logoUrl ?? "https://pikme.in/cdn/logo-banner/pikme-logo-600.png";
      const fullData = { ...itin, hotels: hotelList, days: dayList, mealPlans: mealList };
      const docxBuffer = await generateItineraryDOCX(fullData, companyLogoUrl);
      const key = `docx/${input.id}-${nanoid(8)}.docx`;
      const { url } = await storagePut(key, docxBuffer, "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
      return { url };
    }),
    generatePDF: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      try {
        const itin = await getItineraryById(input.id);
        if (!itin) throw new Error("Itinerary not found");
        const [hotelList, dayList, mealList] = await Promise.all([
          getHotelsByItinerary(input.id),
          getDaysByItinerary(input.id),
          getMealPlansByItinerary(input.id),
        ]);
        const logoUrl = await getAppSetting("logoUrl");
        const companyLogoUrl = logoUrl ?? "https://pikme.in/cdn/logo-banner/pikme-logo-600.png";
        const fullData = { ...itin, hotels: hotelList, days: dayList, mealPlans: mealList };
        const pdfBuffer = await generateItineraryPDF(fullData, companyLogoUrl);
        const key = `pdfs/${input.id}-${nanoid(8)}.pdf`;
        const { url } = await storagePut(key, pdfBuffer, "application/pdf");
        return { url };
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : String(err);
        console.error(`[PDF Generation Error] Failed to generate PDF for itinerary ${input.id}:`, errorMsg);
        throw new Error(`PDF generation failed: ${errorMsg}`);
      }
    }),
  }),

  upload: router({
    getUploadUrl: protectedProcedure
      .input(z.object({ filename: z.string(), contentType: z.string() }))
      .mutation(async ({ input }) => {
        // Return a presigned-style endpoint — we handle via direct upload
        return { uploadEndpoint: "/api/upload", filename: input.filename };
      }),
  }),

  voucher: router({
    list: protectedProcedure.query(async () => getAllVouchers()),

    get: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const v = await getVoucherById(input.id);
      if (!v) throw new Error("Voucher not found");
      return v;
    }),
    publicGet: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const v = await getVoucherById(input.id);
      if (!v) throw new Error("Voucher not found");
      return v;
    }),

    create: protectedProcedure.input(VoucherInput).mutation(async ({ input }) => {
      await createVoucher({
        ...input,
        guestList: input.guestList ?? [],
        inclusions: input.inclusions ?? [],
        hotelAddress: input.hotelAddress ?? null,
        hotelImageUrl: input.hotelImageUrl ?? null,
        specialRequests: input.specialRequests ?? null,
      });
      const all = await getAllVouchers();
      return all[0];
    }),

    update: protectedProcedure
      .input(z.object({ id: z.number(), data: VoucherInput }))
      .mutation(async ({ input }) => {
        await updateVoucher(input.id, {
          ...input.data,
          guestList: input.data.guestList ?? [],
          inclusions: input.data.inclusions ?? [],
          hotelAddress: input.data.hotelAddress ?? null,
          hotelImageUrl: input.data.hotelImageUrl ?? null,
          specialRequests: input.data.specialRequests ?? null,
        });
        return { success: true };
      }),

    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await deleteVoucher(input.id);
      return { success: true };
    }),

    duplicate: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      const duplicated = await duplicateVoucher(input.id);
      return duplicated;
    }),

    generatePDF: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      const v = await getVoucherById(input.id);
      if (!v) throw new Error("Voucher not found");
      const logoUrl = await getAppSetting("logoUrl");
      const companyLogoUrl = logoUrl ?? "https://pikme.in/cdn/logo-banner/pikme-logo-600.png";
      const { generateVoucherPDF } = await import("./voucherPdfGenerator");
      const pdfBuffer = await generateVoucherPDF(v, companyLogoUrl);
      const key = `voucher-pdfs/${input.id}-${nanoid(8)}.pdf`;
      const { url } = await storagePut(key, pdfBuffer, "application/pdf");
      return { url };
    }),
  }),

  settings: router({
    get: publicProcedure.query(async () => {
      const logoUrl = await getAppSetting("logoUrl");
      return {
        logoUrl: logoUrl ?? "https://pikme.in/cdn/logo-banner/pikme-logo-600.png",
      };
    }),

    updateLogo: protectedProcedure
      .input(z.object({ logoUrl: z.string().url() }))
      .mutation(async ({ input }) => {
        await setAppSetting("logoUrl", input.logoUrl);
        return { success: true };
      }),

    resetLogo: protectedProcedure.mutation(async () => {
      await setAppSetting("logoUrl", "https://pikme.in/cdn/logo-banner/pikme-logo-600.png");
      return { success: true };
    }),
  }),
});

export type AppRouter = typeof appRouter;
