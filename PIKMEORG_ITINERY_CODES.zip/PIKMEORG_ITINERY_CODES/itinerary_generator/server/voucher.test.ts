import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { createVoucher, getVoucherById, duplicateVoucher, deleteVoucher, getAllVouchers } from "./db";

describe("Voucher Duplicate", () => {
  let voucherId: number;

  beforeAll(async () => {
    const result = await createVoucher({
      bookingRef: "TEST-001",
      bookingDate: "2026-05-21",
      guestName: "Test Guest",
      guestList: [],
      numGuests: 1,
      hotelName: "Test Hotel",
      hotelAddress: "123 Test St",
      hotelPhone: "555-0123",
      hotelEmail: "test@hotel.com",
      starRating: 4,
      hotelImageUrl: null,
      checkInDate: "2026-05-21",
      checkInTime: "02:00 PM",
      checkOutDate: "2026-05-23",
      checkOutTime: "12:00 PM",
      numNights: 2,
      roomType: "Deluxe",
      numRooms: 1,
      doubleSharing: 1,
      tripleSharing: 0,
      childNoBed: 0,
      childWithBed: 0,
      extraBed: 0,
      mealPlan: "Breakfast & Dinner",
      foodPreference: "Vegetarian",
      inclusions: ["WiFi", "Parking"],
      specialRequests: "Early check-in requested",
      hotelConfirmationNo: "CONF-123",
      agentName: "Test Agent",
      agentPhone: "555-9999",
      earlyCheckIn: 1,
      lateCheckOut: 0,
      status: "draft",
    });
    voucherId = result.id;
  });

  afterAll(async () => {
    const allVouchers = await getAllVouchers();
    for (const v of allVouchers) {
      if (v.bookingRef === "TEST-001" || v.bookingRef?.includes("Copy of TEST-001")) {
        await deleteVoucher(v.id);
      }
    }
  });

  it("should duplicate a voucher with all details", async () => {
    const original = await getVoucherById(voucherId);
    expect(original).toBeDefined();
    expect(original?.bookingRef).toBe("TEST-001");

    const duplicated = await duplicateVoucher(voucherId);
    expect(duplicated).toBeDefined();
    expect(duplicated.id).toBeGreaterThan(0);
    expect(duplicated.id).not.toEqual(voucherId);
    expect(duplicated.bookingRef).toContain("Copy of TEST-001");
    expect(duplicated.guestName).toBe(original?.guestName);
    expect(duplicated.hotelName).toBe(original?.hotelName);
    expect(duplicated.checkInDate).toBe(original?.checkInDate);
    expect(duplicated.checkOutDate).toBe(original?.checkOutDate);
    expect(duplicated.numNights).toBe(original?.numNights);
    expect(duplicated.roomType).toBe(original?.roomType);
    expect(duplicated.mealPlan).toBe(original?.mealPlan);
    expect(duplicated.foodPreference).toBe(original?.foodPreference);
    expect(duplicated.inclusions).toEqual(original?.inclusions);
    expect(duplicated.specialRequests).toBe(original?.specialRequests);
    expect(duplicated.status).toBe("draft");
  });

  it("should throw error when duplicating non-existent voucher", async () => {
    try {
      await duplicateVoucher(99999);
      expect.fail("Should have thrown an error");
    } catch (e) {
      expect((e as Error).message).toContain("Voucher not found");
    }
  });
});
