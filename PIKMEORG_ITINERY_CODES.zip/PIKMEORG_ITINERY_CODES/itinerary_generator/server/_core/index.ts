import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import multer from "multer";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { storagePut } from "../storage";
import { nanoid } from "nanoid";
import { getItineraryById, getHotelsByItinerary, getDaysByItinerary, getMealPlansByItinerary, getVoucherById, getTransportationByItinerary } from "../db";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  // File upload endpoint
  const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });
  app.post("/api/upload", upload.single("file"), async (req: any, res: any) => {
    try {
      if (!req.file) return res.status(400).json({ error: "No file" });
      const ext = req.file.originalname.split(".").pop() || "bin";
      const key = `uploads/${nanoid(12)}.${ext}`;
      const { url } = await storagePut(key, req.file.buffer, req.file.mimetype);
      res.json({ url });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });
  // OAuth callback under /api/oauth/callback
  registerOAuthRoutes(app);
  
  // REST endpoints for public preview (bypasses tRPC to avoid input parsing issues)
  app.get("/api/public/itinerary/:id", async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });
      const itin = await getItineraryById(id);
      if (!itin) return res.status(404).json({ error: "Itinerary not found" });
      const [hotelList, dayList, mealList, transportList] = await Promise.all([
        getHotelsByItinerary(id),
        getDaysByItinerary(id),
        getMealPlansByItinerary(id),
        getTransportationByItinerary(id),
      ]);
      const daysWithTransport = dayList.map(day => ({
        ...day,
        transportationSegments: transportList.filter((t: any) => t.dayId === day.id),
      }));
      res.json({ ...itin, hotels: hotelList, days: daysWithTransport, mealPlans: mealList });
    } catch (e: any) {
      console.error("[Public Itinerary] Error:", e);
      res.status(500).json({ error: e.message });
    }
  });
  
  app.get("/api/public/voucher/:id", async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });
      const v = await getVoucherById(id);
      if (!v) return res.status(404).json({ error: "Voucher not found" });
      res.json(v);
    } catch (e: any) {
      console.error("[Public Voucher] Error:", e);
      res.status(500).json({ error: e.message });
    }
  });
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
