import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser, users,
  itineraries, InsertItinerary,
  hotels, InsertHotel,
  itineraryDays, InsertItineraryDay,
  mealPlans, InsertMealPlan,
  appSettings,
  hotelVouchers, InsertHotelVoucher,
  transportationSegments, InsertTransportationSegment, TransportationSegment,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
    else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) { console.error("[Database] Failed to upsert user:", error); throw error; }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Itineraries ──────────────────────────────────────────────────────────
export async function getAllItineraries() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(itineraries).orderBy(desc(itineraries.updatedAt));
}

export async function getItineraryById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(itineraries).where(eq(itineraries.id, id)).limit(1);
  return result[0];
}

export async function createItinerary(data: InsertItinerary) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(itineraries).values(data);
  return result[0];
}

export async function updateItinerary(id: number, data: Partial<InsertItinerary>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(itineraries).set(data).where(eq(itineraries.id, id));
}

export async function deleteItinerary(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(mealPlans).where(eq(mealPlans.itineraryId, id));
  await db.delete(itineraryDays).where(eq(itineraryDays.itineraryId, id));
  await db.delete(hotels).where(eq(hotels.itineraryId, id));
  await db.delete(itineraries).where(eq(itineraries.id, id));
}

export async function duplicateItinerary(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  
  // Get the original itinerary
  const original = await getItineraryById(id);
  if (!original) throw new Error("Itinerary not found");
  
  // Create new itinerary with "Copy of" prefix - copy ALL fields including cover info, inclusions, exclusions, terms
  const newItinData: InsertItinerary = {
    title: `Copy of ${original.title}`,
    destination: original.destination,
    guestNames: original.guestNames,
    guestList: original.guestList,
    numGuests: original.numGuests,
    startDate: original.startDate,
    endDate: original.endDate,
    numNights: original.numNights,
    numDays: original.numDays,
    mealPlan: original.mealPlan,
    foodPreference: original.foodPreference,
    transfers: original.transfers,
    tripType: original.tripType,
    arrivalType: original.arrivalType,
    arrivalFrom: original.arrivalFrom,
    arrivalTo: original.arrivalTo,
    arrivalFlightNo: original.arrivalFlightNo,
    arrivalAirline: original.arrivalAirline,
    arrivalStops: original.arrivalStops,
    arrivalDepartureDate: original.arrivalDepartureDate,
    arrivalDepartureTime: original.arrivalDepartureTime,
    arrivalArrivalDate: original.arrivalArrivalDate,
    arrivalArrivalTime: original.arrivalArrivalTime,
    returnFlightNo: original.returnFlightNo,
    returnAirline: original.returnAirline,
    returnStops: original.returnStops,
    returnFrom: original.returnFrom,
    returnTo: original.returnTo,
    returnDepartureDate: original.returnDepartureDate,
    returnDepartureTime: original.returnDepartureTime,
    returnArrivalDate: original.returnArrivalDate,
    returnArrivalTime: original.returnArrivalTime,
    coverImageUrl: original.coverImageUrl,
    specialNotes: original.specialNotes,
    inclusions: original.inclusions,
    exclusions: original.exclusions,
    termsAndConditions: original.termsAndConditions,
    status: "draft",
    createdAt: new Date(),
    updatedAt: new Date(),
  };
  
  await db.insert(itineraries).values(newItinData);
  // Get the newly created itinerary by querying the most recent one
  const allItins = await db.select().from(itineraries).orderBy(desc(itineraries.createdAt)).limit(1);
  const newItin = allItins[0];
  if (!newItin) throw new Error("Failed to create new itinerary");
  const newItinId = newItin.id;
  
  // Copy hotels - use db directly instead of calling helper function
  const hotelList = await db.select().from(hotels).where(eq(hotels.itineraryId, id)).orderBy(hotels.sortOrder);
  if (hotelList.length > 0) {
    const newHotels = hotelList.map(h => {
      const newHotel: any = { ...h };
      delete newHotel.id;
      newHotel.itineraryId = newItinId;
      return newHotel;
    });
    await db.insert(hotels).values(newHotels);
  }
  
  // Copy days and create mapping for old day ID -> new day ID
  const dayList = await db.select().from(itineraryDays).where(eq(itineraryDays.itineraryId, id)).orderBy(itineraryDays.dayNumber);
  const dayIdMap = new Map<number, number>();
  
  if (dayList.length > 0) {
    const newDaysData = dayList.map(oldDay => {
      const newDayData: any = { ...oldDay };
      delete newDayData.id;
      newDayData.itineraryId = newItinId;
      return newDayData;
    });
    await db.insert(itineraryDays).values(newDaysData);
    
    // Query the newly inserted days to build the ID mapping
    const newDaysList = await db.select().from(itineraryDays).where(eq(itineraryDays.itineraryId, newItinId)).orderBy(itineraryDays.dayNumber);
    for (let i = 0; i < dayList.length && i < newDaysList.length; i++) {
      dayIdMap.set(dayList[i].id, newDaysList[i].id);
    }
  }
  
  // Copy transportation segments using the day ID mapping
  for (const [oldDayId, newDayId] of Array.from(dayIdMap)) {
    const transportSegs = await db.select().from(transportationSegments).where(eq(transportationSegments.dayId, oldDayId));
    if (transportSegs.length > 0) {
      const newTransportSegs = transportSegs.map(t => {
        const seg: any = { ...t };
        delete seg.id;
        seg.dayId = newDayId;
        return seg;
      });
      await db.insert(transportationSegments).values(newTransportSegs);
    }
  }
  
  // Copy meal plans
  const mealList = await db.select().from(mealPlans).where(eq(mealPlans.itineraryId, id)).orderBy(mealPlans.dayNumber);
  if (mealList.length > 0) {
    const newMeals = mealList.map(m => {
      const newMeal: any = { ...m };
      delete newMeal.id;
      newMeal.itineraryId = newItinId;
      return newMeal;
    });
    await db.insert(mealPlans).values(newMeals);
  }
  
  return newItinId;
}

// ─── Hotels ───────────────────────────────────────────────────────────────
export async function getHotelsByItinerary(itineraryId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(hotels).where(eq(hotels.itineraryId, itineraryId)).orderBy(hotels.sortOrder);
}

export async function upsertHotels(itineraryId: number, data: Omit<InsertHotel, 'itineraryId'>[]) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(hotels).where(eq(hotels.itineraryId, itineraryId));
  if (data.length > 0) {
    await db.insert(hotels).values(data.map((h, i) => ({ ...h, itineraryId, sortOrder: i })));
  }
}

// ─── Itinerary Days ───────────────────────────────────────────────────────
export async function getDaysByItinerary(itineraryId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(itineraryDays).where(eq(itineraryDays.itineraryId, itineraryId)).orderBy(itineraryDays.dayNumber);
}

export async function upsertDays(itineraryId: number, data: Omit<InsertItineraryDay, 'itineraryId'>[]) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(itineraryDays).where(eq(itineraryDays.itineraryId, itineraryId));
  if (data.length > 0) {
    await db.insert(itineraryDays).values(data.map(d => ({ ...d, itineraryId })));
  }
}

// ─── Meal Plans ───────────────────────────────────────────────────────────
export async function getMealPlansByItinerary(itineraryId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(mealPlans).where(eq(mealPlans.itineraryId, itineraryId)).orderBy(mealPlans.dayNumber);
}

export async function upsertMealPlans(itineraryId: number, data: Omit<InsertMealPlan, 'itineraryId'>[]) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(mealPlans).where(eq(mealPlans.itineraryId, itineraryId));
  if (data.length > 0) {
    await db.insert(mealPlans).values(data.map(d => ({ ...d, itineraryId })));
  }
}

// ─── Hotel Vouchers ─────────────────────────────────────────────────────────────
export async function getAllVouchers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(hotelVouchers).orderBy(desc(hotelVouchers.createdAt));
}
export async function getVoucherById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(hotelVouchers).where(eq(hotelVouchers.id, id)).limit(1);
  return rows[0];
}
export async function createVoucher(data: Omit<InsertHotelVoucher, 'id' | 'createdAt' | 'updatedAt'>) {
  const db = await getDb();
  if (!db) throw new Error('DB not available');
  const [result] = await db.insert(hotelVouchers).values(data as InsertHotelVoucher);
  return { id: (result as any).insertId as number };
}
export async function updateVoucher(id: number, data: Partial<Omit<InsertHotelVoucher, 'id' | 'createdAt' | 'updatedAt'>>) {
  const db = await getDb();
  if (!db) throw new Error('DB not available');
  await db.update(hotelVouchers).set(data).where(eq(hotelVouchers.id, id));
}
export async function deleteVoucher(id: number) {
  const db = await getDb();
  if (!db) throw new Error('DB not available');
  await db.delete(hotelVouchers).where(eq(hotelVouchers.id, id));
}

export async function duplicateVoucher(id: number) {
  const db = await getDb();
  if (!db) throw new Error('DB not available');
  
  const original = await getVoucherById(id);
  if (!original) throw new Error('Voucher not found');
  
  const voucherData = { ...original } as any;
  delete voucherData.id;
  delete voucherData.createdAt;
  delete voucherData.updatedAt;
  voucherData.bookingRef = `Copy of ${original.bookingRef}`;
  
  const result = await db.insert(hotelVouchers).values(voucherData as InsertHotelVoucher);
  const insertId = (result as any)[0]?.insertId ?? (result as any).insertId;
  
  if (!insertId) throw new Error('Failed to get inserted ID');
  
  const newVoucher = await getVoucherById(Number(insertId));
  if (!newVoucher) throw new Error('Failed to retrieve duplicated voucher');
  
  return newVoucher;
}
// ─── App Settings ─────────────────────────────────────────────────────────────
export async function getAppSetting(key: string): Promise<string | null> {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(appSettings).where(eq(appSettings.key, key)).limit(1);
  return rows[0]?.value ?? null;
}

export async function setAppSetting(key: string, value: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.insert(appSettings)
    .values({ key, value })
    .onDuplicateKeyUpdate({ set: { value } });
}

// ─── Transportation Segments ───────────────────────────────────────────────
export async function getTransportationByDay(dayId: number): Promise<TransportationSegment[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(transportationSegments).where(eq(transportationSegments.dayId, dayId));
}

export async function getTransportationByItinerary(itineraryId: number): Promise<TransportationSegment[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(transportationSegments).where(eq(transportationSegments.itineraryId, itineraryId));
}

export async function upsertTransportationSegments(itineraryId: number, dayId: number, data: Omit<InsertTransportationSegment, 'itineraryId' | 'dayId'>[]) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(transportationSegments).where(eq(transportationSegments.dayId, dayId));
  if (data.length > 0) {
    await db.insert(transportationSegments).values(data.map(d => ({ ...d, itineraryId, dayId })));
  }
}
