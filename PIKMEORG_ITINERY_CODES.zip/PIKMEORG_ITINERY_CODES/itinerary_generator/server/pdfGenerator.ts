import { readFileSync } from "fs";
import { createRequire } from "module";
import https from "https";
import http from "http";
// docx package loaded dynamically via require (CJS)
import type { Itinerary, Hotel, ItineraryDay, MealPlan } from "../drizzle/schema";

const require = createRequire(import.meta.url);

type FullItinerary = Itinerary & {
  hotels: Hotel[];
  days: ItineraryDay[];
  mealPlans: MealPlan[];
};

// ─── Constants ────────────────────────────────────────────────────────────────
const FOOD_TYPE_LABELS: Record<string, string> = {
  self_paid: "Self Paid",
  complimentary: "Complimentary",
  candle_ld: "Candle L D",
  birthday: "Birthday",
  anniversary: "Anniversary",
  no: "No",
  coupon: "Coupon",
  fixed: "Fixed Menu",
  unlimited: "Unlimited",
  buffet: "Buffet",
  food_with_drink: "Food with Drink",
  drink_only: "Drink Only",
  take_away: "Take Away",
  packed_food: "Packed Food",
  gala_dinner: "Gala Dinner",
  event: "Event",
  others: "Others",
};

function foodLabel(code: string): string {
  return FOOD_TYPE_LABELS[code] || code || "";
}

function starsText(n: number): string {
  return `${Math.min(5, Math.max(1, n))} Star`;
}

function stopsLabel(s: string): string {
  if (s === "direct") return "Direct / Non-Stop";
  if (s === "1stop") return "1 Stop";
  if (s === "2stop") return "2 Stops";
  return s;
}

function mealPlanLabel(code: string): string {
  if (code === "CP") return "CP - Breakfast Only";
  if (code === "MAPI") return "MAPI - Breakfast & Dinner";
  if (code === "AP") return "AP - All Meal Plan";
  if (code === "EP") return "EP - Room Only (No Food)";
  return code;
}

// Strip HTML tags for plain text rendering
function stripHtml(html: string): string {
  if (!html) return "";
  return html
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>/gi, "\n")
    .replace(/<\/li>/gi, "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/&mdash;/g, "\u2014")
    .replace(/&ndash;/g, "\u2013")
    .replace(/&#10003;/g, "Yes")
    .replace(/&#9733;/g, "*")
    .replace(/\u2605/g, "*")
    .replace(/\u2713/g, "Yes")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

// Fetch a URL and return a Buffer (follows HTTP 301/302/307/308 redirects)
function fetchBuffer(url: string, redirectsLeft = 5): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const mod = url.startsWith("https") ? https : http;
    mod.get(url, (res) => {
      const { statusCode, headers } = res;
      // Follow redirects
      if ((statusCode === 301 || statusCode === 302 || statusCode === 307 || statusCode === 308) && headers.location && redirectsLeft > 0) {
        res.resume(); // Drain to free socket
        fetchBuffer(headers.location, redirectsLeft - 1).then(resolve).catch(reject);
        return;
      }
      if (statusCode && statusCode >= 400) {
        res.resume();
        reject(new Error(`HTTP ${statusCode} fetching image: ${url}`));
        return;
      }
      const chunks: Buffer[] = [];
      res.on("data", (c: Buffer) => chunks.push(c));
      res.on("end", () => resolve(Buffer.concat(chunks)));
      res.on("error", reject);
    }).on("error", reject);
  });
}

// Convert buffer to JPEG if it's WebP or unsupported format
async function convertToSupportedFormat(buf: Buffer, mime: string): Promise<{ buffer: Buffer; mime: string } | null> {
  // pdfmake supports: JPEG, PNG, GIF
  if (mime === 'image/jpeg' || mime === 'image/png' || mime === 'image/gif') {
    return { buffer: buf, mime };
  }
  
  // For WebP and other formats, try to convert using sharp if available
  try {
    const sharp = require('sharp');
    const converted = await sharp(buf).jpeg({ quality: 85, progressive: true }).toBuffer();
    return { buffer: converted, mime: 'image/jpeg' };
  } catch (err) {
    console.warn(`[PDF] Failed to convert ${mime} to JPEG:`, err instanceof Error ? err.message : String(err));
    return null;
  }
}

// Fetch a URL and return a base64 data URI
async function fetchBase64(url: string): Promise<string | null> {
  try {
    if (!url) return null;
    // If it's already a data URL, return it as-is
    if (url.startsWith('data:')) return url;
    const buf = await fetchBuffer(url);
    if (!buf || buf.length === 0) return null;
    
    // Detect mime type from buffer magic bytes (more reliable than URL extension)
    let mime: string | null = null;
    
    // Check magic bytes
    if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) {
      mime = "image/png";
    } else if (buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46) {
      mime = "image/gif";
    } else if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) {
      mime = "image/jpeg";
    } else if (buf[0] === 0x52 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x46) {
      // RIFF format - could be WebP or WAV
      // WebP has 'WEBP' at bytes 8-11
      if (buf.length >= 12 && buf[8] === 0x57 && buf[9] === 0x45 && buf[10] === 0x42 && buf[11] === 0x50) {
        mime = "image/webp";
      }
    }
    
    // Fallback to URL extension if magic bytes didn't match
    if (!mime) {
      const ext = url.split('.').pop()?.toLowerCase() || '';
      const mimeMap: Record<string, string> = {
        'jpg': 'image/jpeg',
        'jpeg': 'image/jpeg',
        'png': 'image/png',
        'gif': 'image/gif',
        'webp': 'image/webp',
        'svg': 'image/svg+xml',
      };
      mime = mimeMap[ext] || null;
    }
    
    if (!mime) {
      console.warn(`[PDF] Unable to detect image format for ${url}`);
      return null;
    }
    
    // Convert to supported format if needed
    const converted = await convertToSupportedFormat(buf, mime);
    if (!converted) {
      console.warn(`[PDF] Unable to convert image to supported format: ${url}`);
      return null;
    }
    
    return `data:${converted.mime};base64,${converted.buffer.toString("base64")}`;
  } catch (err) {
    console.warn(`[PDF] Failed to fetch image from ${url}:`, err instanceof Error ? err.message : String(err));
    return null;
  }
}

// ─── pdfmake setup ────────────────────────────────────────────────────────────
let _pdfmakeReady = false;
let _pdfmake: any = null;

function getPdfmake(): any {
  if (_pdfmakeReady) return _pdfmake;
  _pdfmake = require("pdfmake/js/index.js");
  // Load NotoSans fonts from system (supports em-dash, en-dash, and Latin Extended)
  const notoDir = "/usr/share/fonts/truetype/noto/";
  try {
    _pdfmake.virtualfs.writeFileSync("NotoSans-Regular.ttf", readFileSync(notoDir + "NotoSans-Regular.ttf"));
    _pdfmake.virtualfs.writeFileSync("NotoSans-Bold.ttf", readFileSync(notoDir + "NotoSans-Bold.ttf"));
    _pdfmake.virtualfs.writeFileSync("NotoSans-Italic.ttf", readFileSync(notoDir + "NotoSans-Italic.ttf"));
    _pdfmake.virtualfs.writeFileSync("NotoSans-BoldItalic.ttf", readFileSync(notoDir + "NotoSans-BoldItalic.ttf"));
    _pdfmake.addFonts({
      NotoSans: {
        normal: "NotoSans-Regular.ttf",
        bold: "NotoSans-Bold.ttf",
        italics: "NotoSans-Italic.ttf",
        bolditalics: "NotoSans-BoldItalic.ttf",
      },
    });
  } catch {
    // Fallback: use Roboto from pdfmake's own fonts directory
    const robotoDir = require.resolve("pdfmake").replace(/js\/index\.js$/, "fonts/Roboto/");
    _pdfmake.virtualfs.writeFileSync("Roboto-Regular.ttf", readFileSync(robotoDir + "Roboto-Regular.ttf"));
    _pdfmake.virtualfs.writeFileSync("Roboto-Medium.ttf", readFileSync(robotoDir + "Roboto-Medium.ttf"));
    _pdfmake.virtualfs.writeFileSync("Roboto-Italic.ttf", readFileSync(robotoDir + "Roboto-Italic.ttf"));
    _pdfmake.virtualfs.writeFileSync("Roboto-MediumItalic.ttf", readFileSync(robotoDir + "Roboto-MediumItalic.ttf"));
    _pdfmake.addFonts({
      NotoSans: {
        normal: "Roboto-Regular.ttf",
        bold: "Roboto-Medium.ttf",
        italics: "Roboto-Italic.ttf",
        bolditalics: "Roboto-MediumItalic.ttf",
      },
    });
  }
  _pdfmakeReady = true;
  return _pdfmake;
}

// ─── PDF Document Builder ─────────────────────────────────────────────────────
async function buildPdfDocDefinition(data: FullItinerary, companyLogoUrl: string): Promise<any> {
  const d = data as any;

  // Pre-fetch images
  const [logoB64, coverB64, ...hotelB64s] = await Promise.all([
    fetchBase64(companyLogoUrl),
    data.coverImageUrl ? fetchBase64(data.coverImageUrl) : Promise.resolve(null),
    ...data.hotels.map((h) => (h.imageUrl ? fetchBase64(h.imageUrl) : Promise.resolve(null))),
  ]);
  const dayB64s = await Promise.all(
    data.days.map((day) => (day.imageUrl ? fetchBase64(day.imageUrl) : Promise.resolve(null)))
  );

  const guestList: Array<{ name: string; category: string }> =
    Array.isArray(d.guestList) && d.guestList.length
      ? d.guestList
      : (data.guestNames || "")
          .split("\n")
          .filter(Boolean)
          .map((n: string) => ({ name: n, category: "" }));

  const inclusions: string[] = Array.isArray(data.inclusions) ? (data.inclusions as string[]) : [];
  const exclusions: string[] = Array.isArray(data.exclusions) ? (data.exclusions as string[]) : [];

  const RED = "#e53e3e";
  const DARK = "#1a202c";
  const GRAY = "#555555";
  const LIGHT_GRAY = "#f5f5f5";
  const BORDER = "#dddddd";

  const content: any[] = [];

  // ── Header: Logo ──
  if (logoB64) {
    content.push({ image: logoB64, width: 160, margin: [0, 0, 0, 8] });
  } else {
    content.push({ text: "PIKME", fontSize: 22, bold: true, color: RED, margin: [0, 0, 0, 8] });
  }

  // ── Cover Image ──
  if (coverB64) {
    content.push({ image: coverB64, width: 515, height: 180, fit: [515, 180], margin: [0, 0, 0, 12] });
  }

  // ── Title ──
  content.push({
    text: (data.destination || data.title || "").toUpperCase(),
    fontSize: 22,
    bold: true,
    color: DARK,
    margin: [0, 4, 0, 4],
  });
  content.push({ canvas: [{ type: "line", x1: 0, y1: 0, x2: 515, y2: 0, lineWidth: 2, lineColor: RED }], margin: [0, 0, 0, 12] });

  // ── Key Details ──
  const keyDetails: any[] = [];
  keyDetails.push({ text: [{ text: "Duration: ", bold: true }, `${data.numNights}N / ${data.numDays}D`] });
  if (data.startDate && data.endDate) {
    keyDetails.push({ text: [{ text: "Dates: ", bold: true }, `${data.startDate} \u2013 ${data.endDate}`] });
  }
  if (data.numGuests) {
    keyDetails.push({ text: [{ text: "Guests: ", bold: true }, `${data.numGuests} Pax`] });
  }
  if (data.transfers) {
    keyDetails.push({ text: [{ text: "Transfers: ", bold: true }, data.transfers] });
  }
  content.push({ stack: keyDetails, margin: [0, 0, 0, 8] });

  // ── Guest List ──
  if (guestList.length > 0) {
    content.push({ text: "Guests", fontSize: 11, bold: true, margin: [0, 4, 0, 2] });
    content.push({
      ul: guestList.map((g) => g.name + (g.category ? ` (${g.category})` : "")),
      margin: [0, 0, 0, 8],
    });
  }

  // ── Flight / Travel Details ──
  const hasArrival = !!(d.arrivalFrom || d.arrivalTo || d.arrivalFlightNo);
  const hasReturn = !!(d.returnFlightNo || d.returnDepartureDate);
  const isTrainTrip = d.tripType === "train-rt" || d.tripType === "train-ow";
  const vehicleLabel = isTrainTrip ? "Train" : "Flight";

  if (hasArrival || hasReturn) {
    content.push(sectionHeader(`${vehicleLabel} / Travel Details`, RED));
    const flightRows: any[][] = [
      [
        { text: "Direction", bold: true, fillColor: LIGHT_GRAY },
        { text: "Date", bold: true, fillColor: LIGHT_GRAY },
        { text: "From", bold: true, fillColor: LIGHT_GRAY },
        { text: "To", bold: true, fillColor: LIGHT_GRAY },
        { text: `${vehicleLabel} No.`, bold: true, fillColor: LIGHT_GRAY },
        { text: "Dep.", bold: true, fillColor: LIGHT_GRAY },
        { text: "Arr.", bold: true, fillColor: LIGHT_GRAY },
      ],
    ];
    if (hasArrival) {
      flightRows.push([
        "Arrival",
        d.arrivalDate || "",
        d.arrivalFrom || "",
        d.arrivalTo || "",
        d.arrivalFlightNo || "",
        d.arrivalDepartureTime || "",
        d.arrivalArrivalTime || "",
      ]);
    }
    if (hasReturn) {
      flightRows.push([
        "Return",
        d.returnDepartureDate || "",
        d.returnFrom || "",
        d.returnTo || "",
        d.returnFlightNo || "",
        d.returnDepartureTime || "",
        d.returnArrivalTime || "",
      ]);
    }
    content.push({
      table: {
        headerRows: 1,
        widths: ["auto", "auto", "*", "*", "auto", "auto", "auto"],
        body: flightRows,
      },
      layout: "lightHorizontalLines",
      margin: [0, 4, 0, 12],
    });
  }

  // ── Special Notes ──
  if (data.specialNotes) {
    content.push(sectionHeader("Special Notes / Requests", RED));
    content.push({ text: data.specialNotes, color: GRAY, margin: [0, 4, 0, 12] });
  }

  // ── Hotel Detail ──
  if (data.hotels.length > 0) {
    content.push(sectionHeader("Hotel Detail", RED));
    data.hotels.forEach((h, idx) => {
      const imgB64 = hotelB64s[idx];
      const nr = (h as any).numRooms || 0;
      const ds = (h as any).doubleSharing || 0;
      const ts = (h as any).tripleSharing || 0;
      const cnb = (h as any).childNoBed || 0;
      const cwb = (h as any).childWithBed || 0;
      const eb = (h as any).extraBed || 0;
      const roomParts = [
        nr ? `${nr} Room${nr !== 1 ? "s" : ""}` : "",
        ds ? `Double x${ds}` : "",
        ts ? `Triple x${ts}` : "",
        cnb ? `Child No Bed x${cnb}` : "",
        cwb ? `Child With Bed x${cwb}` : "",
        eb ? `Extra Bed x${eb}` : "",
      ].filter(Boolean);

      const hotelInfo: any[] = [
        { text: `${starsText(h.starRating)}${(h as any).destinationName ? " | " + (h as any).destinationName : ""}`, color: RED, fontSize: 9, margin: [0, 0, 0, 2] },
        { text: `${h.numNights}N Stay @ ${h.name} (${h.starRating} Star)`, bold: true, fontSize: 12, margin: [0, 0, 0, 2] },
        { text: `Check-in: ${h.checkInTime || ""} ${h.checkInDate || ""}   Check-out: ${h.checkOutTime || ""} ${h.checkOutDate || ""}`, fontSize: 10 },
      ];
      if (roomParts.length) {
        hotelInfo.push({ text: roomParts.join(" | "), fontSize: 9, color: GRAY, margin: [0, 2, 0, 0] });
      }
      const hotelMealPlan = (h as any).mealPlan;
      const hotelFoodPref = (h as any).foodPreference;
      if (hotelMealPlan || hotelFoodPref) {
        const foodParts = [
          hotelMealPlan ? `Meal Plan: ${mealPlanLabel(hotelMealPlan)}` : "",
          hotelFoodPref ? `Food Pref: ${hotelFoodPref}` : "",
        ].filter(Boolean);
        hotelInfo.push({ text: foodParts.join("  |  "), fontSize: 9, color: GRAY, margin: [0, 2, 0, 0] });
      }
      if ((h as any).specialNotes) {
        hotelInfo.push({ text: (h as any).specialNotes, fontSize: 9, italics: true, color: GRAY, margin: [0, 2, 0, 0] });
      }

      if (imgB64) {
        content.push({
          columns: [
            { image: imgB64, width: 130, height: 90, fit: [130, 90] },
            { stack: hotelInfo, margin: [10, 0, 0, 0] },
          ],
          margin: [0, 0, 0, 8],
        });
      } else {
        content.push({ stack: hotelInfo, margin: [0, 0, 0, 8] });
      }
      content.push({ canvas: [{ type: "line", x1: 0, y1: 0, x2: 515, y2: 0, lineWidth: 0.5, lineColor: BORDER }], margin: [0, 0, 0, 8] });
    });
  }

  // ── Detailed Itinerary ──
  if (data.days.length > 0) {
    content.push(sectionHeader("Detailed Itinerary", RED));
    data.days.forEach((day, idx) => {
      const imgB64 = dayB64s[idx];
      const desc = day.description || "";
      const isHtmlDesc = desc.trim().startsWith("<");
      const descText = isHtmlDesc ? stripHtml(desc) : desc;
      const descLines = descText.split("\n").filter(Boolean).map((l) => l.replace(/^[-\u2022]\s*/, ""));

      const dayHeader: any = {
        columns: [
          {
            text: `Day ${day.dayNumber}`,
            color: "#fff",
            bold: true,
            fillColor: RED,
            fontSize: 10,
            width: "auto",
          },
          {
            text: `  ${day.date || ""}${day.title ? " | " + day.title : ""}`,
            bold: true,
            fontSize: 11,
            margin: [6, 0, 0, 0],
          },
        ],
        margin: [0, 0, 0, 4],
      };

      const dayStack: any[] = [
        {
          table: {
            widths: ["auto", "*"],
            body: [[
              { text: `Day ${day.dayNumber}`, color: "#fff", bold: true, fillColor: RED, fontSize: 10, margin: [4, 2, 4, 2] },
              { text: `${day.date || ""}${day.title ? " | " + day.title : ""}`, bold: true, fontSize: 11, margin: [6, 2, 0, 2] },
            ]],
          },
          layout: "noBorders",
          margin: [0, 0, 0, 4],
        },
      ];

      if (descLines.length > 0) {
        dayStack.push({ ul: descLines, fontSize: 10, margin: [0, 0, 0, 4] });
      }

      // Add transportation segments
      if (day.transportationSegments && day.transportationSegments.length > 0) {
        for (const segment of day.transportationSegments) {
          const transportType = segment.type === "flight" ? "Flight" : segment.type === "train" ? "Train" : segment.type === "car" ? "Car" : "Bus";
          const details = segment.type === "flight" ? `${segment.airline || ""} ${segment.flightNumber || ""}`.trim() : segment.type === "train" ? `${segment.trainName || ""} ${segment.trainNumber || ""}`.trim() : segment.type === "car" ? segment.vehicleType || "" : `${segment.vehicleType || ""} ${segment.vehicleNumber || ""}`.trim();
          
          dayStack.push({
            table: {
              widths: ["*", "*"],
              body: [
                [
                  { text: "ORIGIN", bold: true, fontSize: 9, color: "#fff", fillColor: "#d32f2f", margin: [4, 3, 4, 3] },
                  { text: "DESTINATION", bold: true, fontSize: 9, color: "#fff", fillColor: "#d32f2f", margin: [4, 3, 4, 3] },
                ],
                [
                  { text: segment.originLocation || "", bold: true, fontSize: 10, margin: [4, 2, 4, 2] },
                  { text: segment.destinationLocation || "", bold: true, fontSize: 10, margin: [4, 2, 4, 2] },
                ],
                [
                  { text: `${segment.originTime || ""}\n${segment.originDate || ""}`, fontSize: 9, margin: [4, 2, 4, 2] },
                  { text: `${segment.destinationTime || ""}\n${segment.destinationDate || ""}`, fontSize: 9, margin: [4, 2, 4, 2] },
                ],
              ],
            },
            layout: "lightHorizontalLines",
            margin: [0, 4, 0, 4],
          });
          
          if (details) {
            dayStack.push({ text: details, fontSize: 9, italics: true, margin: [0, 2, 0, 2] });
          }
          if (segment.flightNumber) {
            dayStack.push({ text: `Flight: ${segment.flightNumber}`, fontSize: 8, color: "#666", margin: [0, 2, 0, 2] });
          }
        }
      }

      if (imgB64) {
        content.push({
          columns: [
            { image: imgB64, width: 130, height: 90, fit: [130, 90] },
            { stack: dayStack, margin: [10, 0, 0, 0] },
          ],
          margin: [0, 0, 0, 8],
        });
      } else {
        content.push({ stack: dayStack, margin: [0, 0, 0, 8] });
      }
      content.push({ canvas: [{ type: "line", x1: 0, y1: 0, x2: 515, y2: 0, lineWidth: 0.5, lineColor: "#eeeeee" }], margin: [0, 0, 0, 8] });
    });
  }

  // ── Meal Plan ──
  if (data.mealPlans.length > 0) {
    content.push(sectionHeader("Meal Plan", RED));
    const mealRows: any[][] = [
      [
        { text: "Day", bold: true, fillColor: LIGHT_GRAY },
        { text: "Breakfast", bold: true, fillColor: LIGHT_GRAY, alignment: "center" },
        { text: "Lunch", bold: true, fillColor: LIGHT_GRAY, alignment: "center" },
        { text: "Dinner", bold: true, fillColor: LIGHT_GRAY, alignment: "center" },
      ],
    ];
    data.mealPlans.forEach((mp) => {
      const bfLabel = mp.breakfast ? foodLabel((mp as any).breakfastType || "") || "Yes" : "\u2014";
      const lnLabel = mp.lunch ? foodLabel((mp as any).lunchType || "") || "Yes" : "\u2014";
      const dnLabel = mp.dinner ? foodLabel((mp as any).dinnerType || "") || "Yes" : "\u2014";
      mealRows.push([
        { text: `${mp.date || ""}${mp.dayNumber ? ", Day " + mp.dayNumber : ""}`, fontSize: 9 },
        { text: bfLabel, alignment: "center", fontSize: 9 },
        { text: lnLabel, alignment: "center", fontSize: 9 },
        { text: dnLabel, alignment: "center", fontSize: 9 },
      ]);
    });
    content.push({
      table: { headerRows: 1, widths: ["*", "auto", "auto", "auto"], body: mealRows },
      layout: "lightHorizontalLines",
      margin: [0, 4, 0, 12],
    });
  }

  // ── Inclusions ──
  if (inclusions.length > 0) {
    content.push(sectionHeader("Inclusions", RED));
    content.push({ ul: inclusions.map((i) => stripHtml(i)), fontSize: 10, margin: [0, 4, 0, 12] });
  }

  // ── Exclusions ──
  if (exclusions.length > 0) {
    content.push(sectionHeader("Exclusions", RED));
    content.push({ ul: exclusions.map((e) => stripHtml(e)), fontSize: 10, margin: [0, 4, 0, 12] });
  }

  // ── Terms & Conditions ──
  if (data.termsAndConditions) {
    content.push(sectionHeader("Terms & Conditions", RED));
    const termsText = stripHtml(data.termsAndConditions);
    const termsLines = termsText.split("\n").filter(Boolean);
    if (termsLines.length > 1) {
      content.push({ ul: termsLines, fontSize: 9, color: GRAY, margin: [0, 4, 0, 12] });
    } else {
      content.push({ text: termsText, fontSize: 9, color: GRAY, margin: [0, 4, 0, 12] });
    }
  }

  // ── Footer ──
  content.push({ canvas: [{ type: "line", x1: 0, y1: 0, x2: 515, y2: 0, lineWidth: 1, lineColor: BORDER }], margin: [0, 8, 0, 4] });
  content.push({
    text: "#740, 60th Cross, 5th Block, Bashyam Circle, Rajajinagar, Bangalore - 560010",
    fontSize: 8,
    color: GRAY,
    alignment: "center",
  });
  content.push({
    text: "www.pikme.org | tours@pikme.org | Ph: 8088379983",
    fontSize: 8,
    color: GRAY,
    alignment: "center",
  });

  return {
    content,
    defaultStyle: { font: "NotoSans", fontSize: 11, lineHeight: 1.3 },
    pageSize: "A4",
    pageMargins: [40, 40, 40, 40],
    styles: {
      sectionHeader: { fontSize: 13, bold: true, color: "#111111" },
    },
  };
}

function sectionHeader(text: string, color: string): any {
  return {
    stack: [
      { text, fontSize: 13, bold: true, color: "#111111", margin: [0, 12, 0, 2] },
      { canvas: [{ type: "line", x1: 0, y1: 0, x2: 515, y2: 0, lineWidth: 2, lineColor: color }] },
    ],
    margin: [0, 0, 0, 6],
  };
}

// ─── PDF Generator ────────────────────────────────────────────────────────────
export async function generateItineraryPDF(
  data: FullItinerary,
  companyLogoUrl = "https://pikme.in/cdn/logo-banner/pikme-logo-600.png"
): Promise<Buffer> {
  const pdfmake = getPdfmake();
  const docDefinition = await buildPdfDocDefinition(data, companyLogoUrl);
  const doc = pdfmake.createPdf(docDefinition);
  return await doc.getBuffer() as Buffer;
}

// ─── HTML Builder (for DOCX) ──────────────────────────────────────────────────
async function buildHTML(data: FullItinerary, companyLogoUrl: string): Promise<string> {
  const d = data as any;
  const [logob64, coverb64, ...hotelb64s] = await Promise.all([
    fetchBase64(companyLogoUrl),
    data.coverImageUrl ? fetchBase64(data.coverImageUrl) : Promise.resolve(null),
    ...data.hotels.map((h) => (h.imageUrl ? fetchBase64(h.imageUrl) : Promise.resolve(null))),
  ]);
  const dayb64s = await Promise.all(
    data.days.map((day) => (day.imageUrl ? fetchBase64(day.imageUrl) : Promise.resolve(null)))
  );
  const guestList: Array<{ name: string; category: string }> =
    Array.isArray(d.guestList) && d.guestList.length
      ? d.guestList
      : (data.guestNames || "")
          .split("\n")
          .filter(Boolean)
          .map((n: string) => ({ name: n, category: "" }));
  const inclusions: string[] = Array.isArray(data.inclusions) ? (data.inclusions as string[]) : [];
  const exclusions: string[] = Array.isArray(data.exclusions) ? (data.exclusions as string[]) : [];

  const coverImgHtml = coverb64
    ? `<img src="${coverb64}" style="width:100%;max-height:220px;object-fit:cover;display:block;" alt="Cover">`
    : `<div style="width:100%;height:160px;background:#1a202c;display:flex;align-items:center;justify-content:center;">
        <p style="color:#fff;font-size:18pt;font-style:italic;">Travel is our Story</p>
       </div>`;

  const guestHtml = guestList.length === 0
    ? "<p>\u2014</p>"
    : `<ul>${guestList.map((g) => `<li>${g.name}${g.category ? ` <em>(${g.category})</em>` : ""}</li>`).join("")}</ul>`;

  const hotelsHtml = data.hotels.map((h, idx) => {
    const imgSrc = hotelb64s[idx];
    const imgHtml = imgSrc
      ? `<img src="${imgSrc}" style="width:150px;height:100px;object-fit:cover;float:left;margin-right:12px;margin-bottom:4px;" alt="${h.name}">`
      : "";
    const nr = (h as any).numRooms || 0;
    const ds = (h as any).doubleSharing || 0;
    const ts = (h as any).tripleSharing || 0;
    const cnb = (h as any).childNoBed || 0;
    const cwb = (h as any).childWithBed || 0;
    const eb = (h as any).extraBed || 0;
    const roomParts = [
      nr ? `${nr} Room${nr !== 1 ? "s" : ""}` : "",
      ds ? `Double x${ds}` : "",
      ts ? `Triple x${ts}` : "",
      cnb ? `Child No Bed x${cnb}` : "",
      cwb ? `Child With Bed x${cwb}` : "",
      eb ? `Extra Bed x${eb}` : "",
    ].filter(Boolean);
    return `
    <div style="margin-bottom:16px;overflow:hidden;">
      ${imgHtml}
      <div>
        <p style="color:#e53e3e;font-weight:bold;margin:0;">${starsText(h.starRating)}${(h as any).destinationName ? ` &nbsp; <span style="color:#888;font-weight:normal;font-size:9pt;">${(h as any).destinationName}</span>` : ""}</p>
        <p style="font-weight:bold;font-size:12pt;margin:2px 0;"><strong>${h.numNights}N Stay @ ${h.name} (${h.starRating} Star)</strong></p>
        <p style="margin:2px 0;">Check-in: <strong>${h.checkInTime} ${h.checkInDate}</strong> &nbsp; Check-out: <strong>${h.checkOutTime} ${h.checkOutDate}</strong></p>
        ${roomParts.length ? `<p style="margin:2px 0;color:#555;">${roomParts.join(" | ")}</p>` : ""}
        ${(h as any).mealPlan || (h as any).foodPreference ? `<p style="margin:2px 0;color:#555;font-size:9pt;">${[(h as any).mealPlan ? `Meal Plan: ${mealPlanLabel((h as any).mealPlan)}` : "", (h as any).foodPreference ? `Food Pref: ${(h as any).foodPreference}` : ""].filter(Boolean).join("  |  ")}</p>` : ""}
        ${(h as any).specialNotes ? `<p style="margin:2px 0;font-size:9pt;color:#888;font-style:italic;">${(h as any).specialNotes}</p>` : ""}
      </div>
      <div style="clear:both;"></div>
      <hr style="border:none;border-top:1px solid #ddd;margin:8px 0;">
    </div>`;
  }).join("");

  const daysHtml = data.days.map((day, idx) => {
    const imgSrc = dayb64s[idx];
    const imgHtml = imgSrc
      ? `<img src="${imgSrc}" style="width:150px;height:100px;object-fit:cover;float:left;margin-right:12px;margin-bottom:4px;" alt="Day ${day.dayNumber}">`
      : "";
    const desc = day.description || "";
    const isHtmlDesc = desc.trim().startsWith("<");
    const descText = isHtmlDesc ? stripHtml(desc) : desc;
    const descLines = descText.split("\n").filter(Boolean);
    const descHtml = descLines.length > 0
      ? `<ul style="margin:4px 0;padding-left:18px;">${descLines.map((l) => `<li>${l.replace(/^[-\u2022]\s*/, "")}</li>`).join("")}</ul>`
      : `<p>${descText}</p>`;
    return `
    <div style="margin-bottom:16px;overflow:hidden;">
      <p style="background:#e53e3e;color:#fff;font-weight:bold;padding:4px 10px;display:inline-block;border-radius:4px;margin:0;">Day ${day.dayNumber}</p>
      <strong style="margin-left:8px;">${day.date}${day.title ? " | " + day.title : ""}</strong>
      <div style="margin-top:8px;overflow:hidden;">
        ${imgHtml}
        <div>
          <p style="font-weight:bold;margin:0 0 4px;">Itinerary:</p>
          <hr style="border:none;border-top:1px solid #ddd;margin:0 0 6px;">
          ${descHtml}
        </div>
        <div style="clear:both;"></div>
      </div>
      <hr style="border:none;border-top:1px solid #eee;margin:8px 0;">
    </div>`;
  }).join("");

  const mealRowsHtml = data.mealPlans.map((mp) => {
    const bfLabel = mp.breakfast ? foodLabel((mp as any).breakfastType || "") || "Yes" : "\u2014";
    const lnLabel = mp.lunch ? foodLabel((mp as any).lunchType || "") || "Yes" : "\u2014";
    const dnLabel = mp.dinner ? foodLabel((mp as any).dinnerType || "") || "Yes" : "\u2014";
    return `<tr>
      <td>${mp.date || ""}${mp.dayNumber ? ", Day " + mp.dayNumber : ""}</td>
      <td style="text-align:center;">${bfLabel}</td>
      <td style="text-align:center;">${lnLabel}</td>
      <td style="text-align:center;">${dnLabel}</td>
    </tr>`;
  }).join("");

  const inclusionsHtml = inclusions.length > 0
    ? `<h2>Inclusions</h2><ul>${inclusions.map((i) => `<li>${stripHtml(i)}</li>`).join("")}</ul>`
    : "";
  const exclusionsHtml = exclusions.length > 0
    ? `<h2>Exclusions</h2><ul>${exclusions.map((e) => `<li>${stripHtml(e)}</li>`).join("")}</ul>`
    : "";
  const termsHtml = data.termsAndConditions
    ? `<h2>Terms &amp; Conditions</h2><p style="font-size:9pt;color:#555;">${data.termsAndConditions.replace(/\n/g, "<br>")}</p>`
    : "";

  // Flight details
  const hasArrival = !!(d.arrivalFrom || d.arrivalTo || d.arrivalFlightNo);
  const hasReturn = !!(d.returnFlightNo || d.returnDepartureDate);
  const isTrainTrip = d.tripType === "train-rt" || d.tripType === "train-ow";
  const vehicleLabel = isTrainTrip ? "Train" : "Flight";
  let flightHtml = "";
  if (hasArrival || hasReturn) {
    const arrRow = hasArrival
      ? `<tr><td>Arrival</td><td>${d.arrivalDate || ""}</td><td>${d.arrivalFrom || ""}</td><td>${d.arrivalTo || ""}</td><td>${d.arrivalFlightNo || ""}</td><td>${d.arrivalDepartureTime || ""}</td><td>${d.arrivalArrivalTime || ""}</td></tr>`
      : "";
    const retRow = hasReturn
      ? `<tr><td>Return</td><td>${d.returnDepartureDate || ""}</td><td>${d.returnFrom || ""}</td><td>${d.returnTo || ""}</td><td>${d.returnFlightNo || ""}</td><td>${d.returnDepartureTime || ""}</td><td>${d.returnArrivalTime || ""}</td></tr>`
      : "";
    flightHtml = `<h2>${vehicleLabel} / Travel Details</h2>
      <table>
        <thead><tr><th>Direction</th><th>Date</th><th>From</th><th>To</th><th>${vehicleLabel} No.</th><th>Dep.</th><th>Arr.</th></tr></thead>
        <tbody>${arrRow}${retRow}</tbody>
      </table>`;
  }

  const specialNotesHtml = data.specialNotes
    ? `<h2>Special Notes / Requests</h2><p style="color:#555;">${data.specialNotes.replace(/\n/g, "<br>")}</p>`
    : "";

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
  body { font-family: Arial, sans-serif; font-size: 11pt; color: #222; margin: 0; padding: 0; }
  h1 { color: #e53e3e; font-size: 20pt; margin-bottom: 4px; }
  h2 { color: #111; font-size: 13pt; border-bottom: 2px solid #e53e3e; padding-bottom: 4px; margin-top: 20px; }
  h3 { color: #e53e3e; font-size: 11pt; margin: 12px 0 4px; }
  table { width: 100%; border-collapse: collapse; margin: 8px 0; }
  th { background: #f5f5f5; padding: 6px 10px; border: 1px solid #ddd; font-weight: bold; text-align: center; }
  td { padding: 6px 10px; border: 1px solid #ddd; }
  ul { margin: 4px 0; padding-left: 20px; }
  li { margin: 2px 0; }
  .footer { color: #888; font-size: 9pt; text-align: center; margin-top: 24px; border-top: 1px solid #ddd; padding-top: 8px; }
</style>
</head>
<body>
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
  ${logob64 ? `<img src="${logob64}" style="height:56px;object-fit:contain;" alt="Pikme Logo">` : "<strong style='font-size:18pt;color:#e53e3e;'>Pikme</strong>"}
</div>
${coverImgHtml}
<h1>${(data.destination || data.title).toUpperCase()}</h1>
<hr style="border:none;border-top:2px solid #e53e3e;margin:4px 0 12px;">
<p><strong>Duration:</strong> ${data.numNights}N / ${data.numDays}D${data.startDate && data.endDate ? ` &nbsp;&nbsp; <strong>Dates:</strong> ${data.startDate} \u2013 ${data.endDate}` : ""}</p>
${guestList.length > 0 ? `<p><strong>Guests:</strong></p>${guestHtml}` : ""}
${data.transfers ? `<p><strong>Transfers:</strong> ${data.transfers}</p>` : ""}
${flightHtml}
${specialNotesHtml}
<h2>Hotel Detail</h2>
${hotelsHtml}
<h2>Detailed Itinerary</h2>
${daysHtml}
${data.mealPlans.length > 0 ? `
<h2>Meal Plan</h2>
<table>
  <thead>
    <tr><th style="text-align:left;">Day</th><th>Breakfast</th><th>Lunch</th><th>Dinner</th></tr>
  </thead>
  <tbody>${mealRowsHtml}</tbody>
</table>` : ""}
${inclusionsHtml}
${exclusionsHtml}
${termsHtml}
<div class="footer">
  #740, 60th Cross, 5th Block, Bashyam Circle, Rajajinagar, Bangalore - 560010<br>
  www.pikme.org &nbsp;|&nbsp; tours@pikme.org &nbsp;|&nbsp; Ph: 8088379983
</div>
</body>
</html>`;
}

// ─── DOCX Generator ───────────────────────────────────────────────────────────
export async function generateItineraryDOCX(
  data: FullItinerary,
  companyLogoUrl = "https://pikme.in/cdn/logo-banner/pikme-logo-600.png"
): Promise<Buffer> {
  const {
    Document, Packer, Paragraph, TextRun, HeadingLevel,
    Table, TableRow, TableCell, WidthType, AlignmentType,
    ShadingType, BorderStyle,
  } = require("docx");

  const d = data as any;
  const RED = "E53E3E";
  const GRAY = "555555";

  const guestList: Array<{ name: string; category: string }> =
    Array.isArray(d.guestList) && d.guestList.length
      ? d.guestList
      : (data.guestNames || "")
          .split("\n")
          .filter(Boolean)
          .map((n: string) => ({ name: n, category: "" }));

  const inclusions: string[] = Array.isArray(data.inclusions) ? (data.inclusions as string[]) : [];
  const exclusions: string[] = Array.isArray(data.exclusions) ? (data.exclusions as string[]) : [];

  function heading(text: string): any {
    return new Paragraph({
      children: [new TextRun({ text, bold: true, size: 28 })],
      spacing: { before: 240, after: 120 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: RED } },
    });
  }

  function bold(label: string, value: string): any {
    return new Paragraph({
      children: [
        new TextRun({ text: label, bold: true }),
        new TextRun(value),
      ],
      spacing: { after: 60 },
    });
  }

  function bullet(text: string): any {
    return new Paragraph({
      text: stripHtml(text),
      bullet: { level: 0 },
      spacing: { after: 40 },
    });
  }

  function tableRow(cells: string[], isHeader = false): any {
    return new TableRow({
      children: cells.map((c) =>
        new TableCell({
          children: [new Paragraph({
            children: [new TextRun({ text: c, bold: isHeader })],
            alignment: AlignmentType.CENTER,
          })],
          shading: isHeader ? { type: ShadingType.SOLID, color: "F5F5F5" } : undefined,
        })
      ),
    });
  }

  const children: any[] = [];

  // Title
  children.push(new Paragraph({
    children: [new TextRun({ text: (data.destination || data.title || "").toUpperCase(), bold: true, size: 48 })],
    spacing: { after: 120 },
  }));

  // Key details
  children.push(bold("Duration: ", `${data.numNights}N / ${data.numDays}D`));
  if (data.startDate && data.endDate) {
    children.push(bold("Dates: ", `${data.startDate} \u2013 ${data.endDate}`));
  }
  if (data.numGuests) children.push(bold("Guests: ", `${data.numGuests} Pax`));
  if (data.transfers) children.push(bold("Transfers: ", data.transfers));

  // Guest list
  if (guestList.length > 0) {
    children.push(new Paragraph({ text: "Guests", spacing: { before: 160, after: 60 }, children: [new TextRun({ text: "Guests", bold: true })] }));
    guestList.forEach((g) => children.push(bullet(g.name + (g.category ? ` (${g.category})` : ""))));
  }

  // Special notes
  if (data.specialNotes) {
    children.push(heading("Special Notes / Requests"));
    children.push(new Paragraph({ children: [new TextRun({ text: data.specialNotes, color: GRAY })], spacing: { after: 120 } }));
  }

  // Flight details
  const hasArrival = !!(d.arrivalFrom || d.arrivalTo || d.arrivalFlightNo);
  const hasReturn = !!(d.returnFlightNo || d.returnDepartureDate);
  const isTrainTrip = d.tripType === "train-rt" || d.tripType === "train-ow";
  const vehicleLabel = isTrainTrip ? "Train" : "Flight";
  if (hasArrival || hasReturn) {
    children.push(heading(`${vehicleLabel} / Travel Details`));
    const flightRows = [tableRow(["Direction", "Date", "From", "To", vehicleLabel + " No.", "Dep.", "Arr."], true)];
    if (hasArrival) flightRows.push(tableRow(["Arrival", d.arrivalDate || "", d.arrivalFrom || "", d.arrivalTo || "", d.arrivalFlightNo || "", d.arrivalDepartureTime || "", d.arrivalArrivalTime || ""]));
    if (hasReturn) flightRows.push(tableRow(["Return", d.returnDepartureDate || "", d.returnFrom || "", d.returnTo || "", d.returnFlightNo || "", d.returnDepartureTime || "", d.returnArrivalTime || ""]));
    children.push(new Table({ rows: flightRows, width: { size: 100, type: WidthType.PERCENTAGE } }));
    children.push(new Paragraph({ text: "", spacing: { after: 120 } }));
  }

  // Hotels
  if (data.hotels.length > 0) {
    children.push(heading("Hotel Detail"));
    data.hotels.forEach((h: any) => {
      children.push(new Paragraph({ children: [new TextRun({ text: starsText(h.starRating) + (h.destinationName ? " | " + h.destinationName : ""), color: RED })] }));
      children.push(new Paragraph({ children: [new TextRun({ text: h.numNights + "N Stay @ " + h.name + " (" + h.starRating + " Star)", bold: true, size: 26 })] }));
      children.push(new Paragraph({ children: [new TextRun("Check-in: " + (h.checkInTime || "") + " " + (h.checkInDate || "") + "   Check-out: " + (h.checkOutTime || "") + " " + (h.checkOutDate || ""))] }));
      const roomParts = [
        h.numRooms ? `${h.numRooms} Room${h.numRooms !== 1 ? "s" : ""}` : "",
        h.doubleSharing ? `Double x${h.doubleSharing}` : "",
        h.tripleSharing ? `Triple x${h.tripleSharing}` : "",
        h.childNoBed ? `Child No Bed x${h.childNoBed}` : "",
        h.childWithBed ? `Child With Bed x${h.childWithBed}` : "",
        h.extraBed ? `Extra Bed x${h.extraBed}` : "",
      ].filter(Boolean);
      if (roomParts.length) children.push(new Paragraph({ children: [new TextRun({ text: roomParts.join(" | "), color: GRAY, size: 20 })] }));
      if (h.mealPlan || h.foodPreference) {
        const foodParts = [
          h.mealPlan ? `Meal Plan: ${mealPlanLabel(h.mealPlan)}` : "",
          h.foodPreference ? `Food Pref: ${h.foodPreference}` : "",
        ].filter(Boolean);
        children.push(new Paragraph({ children: [new TextRun({ text: foodParts.join("  |  "), color: GRAY, size: 20 })] }));
      }
      if (h.specialNotes) children.push(new Paragraph({ children: [new TextRun({ text: h.specialNotes, italics: true, color: GRAY, size: 20 })] }));
      children.push(new Paragraph({ text: "", spacing: { after: 80 } }));
    });
  }

  // Days
  if (data.days.length > 0) {
    children.push(heading("Detailed Itinerary"));
    data.days.forEach((day: any) => {
      children.push(new Paragraph({
        children: [
          new TextRun({ text: `Day ${day.dayNumber}`, bold: true, color: "FFFFFF", highlight: "red" }),
          new TextRun({ text: `  ${day.date || ""}${day.title ? " | " + day.title : ""}`, bold: true }),
        ],
        spacing: { after: 60 },
      }));
      const desc = day.description || "";
      const isHtmlDesc = desc.trim().startsWith("<");
      const descText = isHtmlDesc ? stripHtml(desc) : desc;
      const descLines = descText.split("\n").filter(Boolean);
      descLines.forEach((l: string) => children.push(bullet(l.replace(/^[-\u2022]\s*/, ""))));
      children.push(new Paragraph({ text: "", spacing: { after: 80 } }));
    });
  }

  // Meal plan
  if (data.mealPlans.length > 0) {
    children.push(heading("Meal Plan"));
    const mealRows = [tableRow(["Day", "Breakfast", "Lunch", "Dinner"], true)];
    data.mealPlans.forEach((mp: any) => {
      const bfLabel = mp.breakfast ? foodLabel(mp.breakfastType || "") || "Yes" : "\u2014";
      const lnLabel = mp.lunch ? foodLabel(mp.lunchType || "") || "Yes" : "\u2014";
      const dnLabel = mp.dinner ? foodLabel(mp.dinnerType || "") || "Yes" : "\u2014";
      mealRows.push(tableRow([`${mp.date || ""}${mp.dayNumber ? ", Day " + mp.dayNumber : ""}`, bfLabel, lnLabel, dnLabel]));
    });
    children.push(new Table({ rows: mealRows, width: { size: 100, type: WidthType.PERCENTAGE } }));
    children.push(new Paragraph({ text: "", spacing: { after: 120 } }));
  }

  // Inclusions
  if (inclusions.length > 0) {
    children.push(heading("Inclusions"));
    inclusions.forEach((i) => children.push(bullet(i)));
    children.push(new Paragraph({ text: "", spacing: { after: 80 } }));
  }

  // Exclusions
  if (exclusions.length > 0) {
    children.push(heading("Exclusions"));
    exclusions.forEach((e) => children.push(bullet(e)));
    children.push(new Paragraph({ text: "", spacing: { after: 80 } }));
  }

  // Terms
  if (data.termsAndConditions) {
    children.push(heading("Terms & Conditions"));
    const termsLines = stripHtml(data.termsAndConditions).split("\n").filter(Boolean);
    termsLines.forEach((l) => children.push(new Paragraph({ children: [new TextRun({ text: l, size: 18, color: GRAY })], spacing: { after: 40 } })));
  }

  // Footer
  children.push(new Paragraph({ text: "", spacing: { before: 240 } }));
  children.push(new Paragraph({
    children: [new TextRun({ text: "#740, 60th Cross, 5th Block, Bashyam Circle, Rajajinagar, Bangalore - 560010", size: 16, color: GRAY })],
    alignment: AlignmentType.CENTER,
  }));
  children.push(new Paragraph({
    children: [new TextRun({ text: "www.pikme.org | tours@pikme.org | Ph: 8088379983", size: 16, color: GRAY })],
    alignment: AlignmentType.CENTER,
  }));

  const doc = new Document({
    sections: [{
      properties: {},
      children,
    }],
  });

  return await Packer.toBuffer(doc);
}
